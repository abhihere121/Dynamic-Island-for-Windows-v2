// Service tests that run anywhere: fake Windows notification DB + sample ICS.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { NotificationWatcher, parsePayload, appName, classify } = require('../src/services/notifications');
const { expand } = require('../src/services/calendar');
const ical = require('node-ical');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wpn-test-'));
const dbPath = path.join(dir, 'wpndatabase.db');
const db = new DatabaseSync(dbPath);
db.exec(`CREATE TABLE NotificationHandler(RecordId INTEGER PRIMARY KEY, PrimaryId TEXT);
CREATE TABLE Notification(Id INTEGER PRIMARY KEY, HandlerId INTEGER, Type TEXT, Payload BLOB, ArrivalTime INTEGER);
INSERT INTO NotificationHandler VALUES (1,'5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App'),(2,'Microsoft.Office.OUTLOOK.EXE.15'),(3,'Slack');`);
const toast = (a, b) => `<toast><visual><binding template="ToastGeneric"><text>${a}</text><text>${b}</text><text placement="attribution">via X</text></binding></visual></toast>`;
const ft = (BigInt(Date.now()) + 11644473600000n) * 10000n;
const ins = db.prepare('INSERT INTO Notification(HandlerId,Type,Payload,ArrivalTime) VALUES (?,?,?,?)');
ins.run(3, 'toast', toast('old', 'history'), ft);
db.close();

const w = new NotificationWatcher({ dbPath, tmpDir: dir });
w.poll(); // baseline: history ignored
assert.equal(w.list().length, 0);
const db2 = new DatabaseSync(dbPath);
const ins2 = db2.prepare('INSERT INTO Notification(HandlerId,Type,Payload,ArrivalTime) VALUES (?,?,?,?)');
ins2.run(1, 'toast', toast('Priya', 'Are we on &amp; ready?'), ft);
ins2.run(2, 'toast', toast('Invoice overdue', 'Please pay'), ft);
ins2.run(1, 'badge', '<badge/>', ft);
db2.close();
w.poll();
const l = w.list();
assert.equal(l.length, 2);
assert.deepEqual([l[0].kind, l[0].title, l[1].kind, l[1].body], ['mail', 'Invoice overdue', 'whatsapp', 'Are we on & ready?']);
assert.equal(appName('5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App'), 'WhatsApp Desktop');
assert.equal(classify('Chrome', 'Rahul', 'web.whatsapp.com'), 'whatsapp');
assert.ok(Math.abs(l[0].ts - Date.now()) < 5000);
console.log('notifications ok');

const tomorrow = new Date(Date.now() + 86400000).toISOString().replace(/[-:]/g, '').slice(0, 8);
const ics = `BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nUID:1\nDTSTART:${tomorrow}T090000Z\nDTEND:${tomorrow}T093000Z\nSUMMARY:Standup\nDESCRIPTION:Join https://meet.google.com/abc-defg-hij now\nRRULE:FREQ=DAILY;COUNT=3\nEND:VEVENT\nEND:VCALENDAR`;
const evs = expand(Object.values(ical.sync.parseICS(ics)), new Date(), new Date(Date.now() + 7 * 86400000));
assert.equal(evs.length, 3);
assert.equal(evs[0].joinUrl, 'https://meet.google.com/abc-defg-hij');
console.log('calendar ok');
