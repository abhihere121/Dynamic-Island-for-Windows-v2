const assert = require('assert');
const { ClaudeWatcher } = require('../src/services/claude');
const w = new ClaudeWatcher(47998); w.start();
const post = (p, b) => fetch('http://127.0.0.1:47998' + p, { method: 'POST', body: JSON.stringify(b) }).then((r) => r.text());
(async () => {
  const reqs = []; w.on('request', (r) => reqs.push(r));
  // permission: allow
  let p = post('/claude/permission', { session_id: 's', tool_name: 'Bash', tool_input: { command: 'rm -rf build' } });
  await new Promise((r) => setTimeout(r, 100));
  assert.equal(reqs[0].tool, 'Bash'); assert.equal(reqs[0].detail, 'rm -rf build');
  assert.equal(w.summary().state, 'waiting');
  w.answer(reqs[0].id, 'allow');
  const out = JSON.parse(await p);
  assert.equal(out.hookSpecificOutput.decision.behavior, 'allow');
  assert.equal(w.summary().state, 'working');
  // deny
  p = post('/claude/permission', { session_id: 's', tool_name: 'Edit', tool_input: { file_path: 'a.txt' } });
  await new Promise((r) => setTimeout(r, 100)); w.answer(reqs[1].id, 'deny');
  assert.equal(JSON.parse(await p).hookSpecificOutput.decision.behavior, 'deny');
  // reply
  p = post('/claude/stop-reply', { session_id: 's', last_assistant_message: 'All done' });
  await new Promise((r) => setTimeout(r, 100));
  assert.equal(w.summary().reply, true);
  w.answer(reqs[2].id, 'reply', 'also add tests');
  assert.deepEqual(JSON.parse(await p), { decision: 'block', reason: 'The user replied from Dynamic Island: also add tests' });
  // dismiss => empty body (Claude Code proceeds normally)
  p = post('/claude/stop-reply', { session_id: 's' });
  await new Promise((r) => setTimeout(r, 100)); w.answer(reqs[3].id, 'dismiss');
  assert.equal(await p, '');
  assert.equal(w.pending.size, 0);
  console.log('claude hold/answer ok'); w.stop();
})().catch((e) => { console.error(e); process.exit(1); });
