const assert = require('assert');
const { TimerService, nextOccurrence } = require('../src/services/timers');
const { WeatherWatcher, describe } = require('../src/services/weather');

const store = { d: {}, get: (k) => store.d[k], set: (p) => Object.assign(store.d, p) };
const t = new TimerService(store);
const fired = [];
t.on('fire', (x) => fired.push(x));
t.add({ kind: 'timer', minutes: 5, label: 'tea' });
t.add({ kind: 'timer', minutes: 0 }); // clamps to 1 minute
assert.equal(t.list().length, 2);
assert.ok(t.list()[0].endAt - Date.now() > 59000 && t.list()[0].endAt - Date.now() <= 60000);
assert.equal(store.d.timers.length, 2);
// force one to be due
t.items[0].endAt = Date.now() - 10;
t.check();
assert.equal(fired.length, 1);
assert.equal(t.list().length, 1);
t.remove(t.list()[0].id);
assert.equal(t.list().length, 0);
assert.equal(t.t, null);
// alarms
const now = new Date(2026, 9, 25, 10, 0, 0).getTime();
assert.equal(new Date(nextOccurrence('11:30', now)).getHours(), 11);
assert.equal(new Date(nextOccurrence('09:00', now)).getDate(), 26); // already passed -> tomorrow
t.add({ kind: 'alarm', time: '07:30', daily: true });
t.items[0].endAt = Date.now() - 10;
t.check();
assert.equal(t.list().length, 1); // daily alarm re-armed
assert.ok(t.list()[0].endAt > Date.now());
t.stop();
// startup: long-overdue timers do not ring
const s2 = { d: { timers: [{ id: 1, kind: 'timer', endAt: Date.now() - 3600000 }] }, get: (k) => s2.d[k], set: (p) => Object.assign(s2.d, p) };
const t2 = new TimerService(s2); const f2 = []; t2.on('fire', (x) => f2.push(x)); t2.start(); t2.stop();
assert.equal(f2.length, 0);

const w = WeatherWatcher.parse({ current: { temperature_2m: 28.4, apparent_temperature: 31.2, weather_code: 2, is_day: 1 }, daily: { temperature_2m_max: [31.1], temperature_2m_min: [22.6] } }, 'Mumbai', 'c');
assert.deepEqual(w, { temp: 28, feels: 31, hi: 31, lo: 23, icon: 'cloud-sun', label: 'Partly cloudy', city: 'Mumbai', units: 'c' });
assert.equal(describe(61, true).icon, 'cloud-rain');
assert.equal(describe(0, false).icon, 'moon');
console.log('timers+weather ok');
