const assert = require('assert');
const { parseDevices } = require('../src/services/bluetooth');
const d = parseDevices('[{"address":"aabbccddeeff","name":"WH-1000XM4","connected":true,"battery":82},{"address":"112233445566","name":"Keyboard","connected":false,"battery":null},{"address":"bad","name":"x"}]');
assert.equal(d.length, 2);
assert.deepEqual(d[0], { address: 'AABBCCDDEEFF', name: 'WH-1000XM4', connected: true, battery: 82 });
assert.equal(d[1].battery, null);
assert.equal(parseDevices('{"address":"AABBCCDDEEFF","name":"Solo","connected":false}').length, 1); // single object
assert.deepEqual(parseDevices('[]'), []);
assert.equal(parseDevices('not json'), null);
assert.equal(parseDevices('[{"address":"AABBCCDDEEFF","battery":250}]')[0].battery, null);
console.log('bluetooth ok');
