// Dev helper: screenshots every tab of the UI in headless Chromium using the mock API.
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 620, height: 250 }, deviceScaleFactor: 2 });
  p.on('console', (m) => m.type() === 'error' && console.log('console error:', m.text()));
  p.on('pageerror', (e) => console.log('page error:', e.message));
  await p.addInitScript(() => { addEventListener('DOMContentLoaded', () => { document.documentElement.style.background = '#6b7a99'; }); });
  await p.goto('file://' + path.resolve(__dirname, '../src/renderer/index.html'));
  await p.waitForTimeout(900);
  const out = process.argv[2] || '.';
  for (const t of ['now', 'calendar', 'alerts', 'clips', 'notes']) {
    await p.click(`[data-tab=${t}]`);
    await p.waitForTimeout(500);
    await p.screenshot({ path: `${out}/${t}.png` });
  }
  await p.click('#gearBtn'); await p.waitForTimeout(400);
  await p.screenshot({ path: `${out}/settings.png` });
  await b.close();
})();
