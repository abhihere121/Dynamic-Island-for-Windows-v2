// Writes assets/icon.png (256x256): a black pill with a small light dot.
const zlib = require('zlib');
const fs = require('fs');
const path = require('path');

const N = 256;
const px = Buffer.alloc(N * N * 4);
const inPill = (x, y) => {
  const cx = Math.min(Math.max(x, 70), N - 70);
  return (x - cx) ** 2 + (y - N / 2) ** 2 <= 46 ** 2 && Math.abs(y - N / 2) <= 46;
};
for (let y = 0; y < N; y++)
  for (let x = 0; x < N; x++) {
    const i = (y * N + x) * 4;
    if (inPill(x, y)) {
      const dot = (x - 188) ** 2 + (y - 128) ** 2 <= 16 ** 2;
      px.set(dot ? [120, 220, 150, 255] : [20, 20, 22, 255], i);
    }
  }
const raw = Buffer.alloc((N * 4 + 1) * N);
for (let y = 0; y < N; y++) px.copy(raw, y * (N * 4 + 1) + 1, y * N * 4, (y + 1) * N * 4);
const crcTable = Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
const crc = (b) => {
  let c = 0xffffffff;
  for (const v of b) c = crcTable[(c ^ v) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
const chunk = (type, data) => {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const c = Buffer.alloc(4);
  c.writeUInt32BE(crc(td));
  return Buffer.concat([len, td, c]);
};
const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(N, 0);
ihdr.writeUInt32BE(N, 4);
ihdr[8] = 8;
ihdr[9] = 6;
fs.writeFileSync(
  path.join(__dirname, '..', 'assets', 'icon.png'),
  Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ]),
);
