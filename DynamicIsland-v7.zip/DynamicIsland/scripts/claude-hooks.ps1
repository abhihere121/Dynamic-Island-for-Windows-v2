# Adds (or with -Remove, removes) Claude Code hooks that talk to the island.
#   default : status pill + approve/deny permission prompts from the island
#   -Reply  : also holds ~9s after each turn so you can type a reply in the island
param([switch]$Remove, [switch]$Reply)
$path = Join-Path $env:USERPROFILE '.claude\settings.json'
New-Item -ItemType Directory -Force (Split-Path $path) | Out-Null
if (Test-Path $path) {
  Copy-Item $path "$path.bak" -Force
  $cfg = Get-Content $path -Raw | ConvertFrom-Json
} else { $cfg = [pscustomobject]@{} }
if (-not $cfg.PSObject.Properties['hooks']) { $cfg | Add-Member hooks ([pscustomobject]@{}) }

$stop = if ($Reply) { @{ p = 'stop-reply'; m = 12; t = 14 } } else { @{ p = 'done'; m = 2; t = 5 } }
$defs = [ordered]@{
  UserPromptSubmit  = @{ p = 'working';    m = 2;  t = 5 }
  PostToolUse       = @{ p = 'working';    m = 2;  t = 5 }
  Notification      = @{ p = 'waiting';    m = 2;  t = 5 }
  PermissionRequest = @{ p = 'permission'; m = 28; t = 30 }
  Stop              = $stop
}
$marker = '127\.0\.0\.1:47821'
foreach ($ev in $defs.Keys) {
  $d = $defs[$ev]
  $has = [bool]$cfg.hooks.PSObject.Properties[$ev]
  $existing = @(); if ($has) { $existing = @($cfg.hooks.$ev) }
  $others = @($existing | Where-Object { ($_ | ConvertTo-Json -Depth 8) -notmatch $marker })
  if ($Remove) { $new = $others }
  else {
    $cmd = "curl -s -m $($d.m) -X POST --data-binary @- http://127.0.0.1:47821/claude/$($d.p)"
    $entry = [pscustomobject]@{ hooks = @([pscustomobject]@{ type = 'command'; command = $cmd; timeout = $d.t }) }
    $new = $others + $entry
  }
  if ($new.Count -gt 0) {
    if ($has) { $cfg.hooks.$ev = $new } else { $cfg.hooks | Add-Member $ev $new }
  } elseif ($has) { $cfg.hooks.PSObject.Properties.Remove($ev) }
}
$json = $cfg | ConvertTo-Json -Depth 20
[IO.File]::WriteAllText($path, $json, (New-Object Text.UTF8Encoding $false))
if ($Remove) { Write-Host 'Claude hooks removed.' } else { Write-Host "Claude hooks added to $path (backup: settings.json.bak)" }
