// Browser-only stand-in for the Electron preload so the UI can be previewed
// (and screenshotted) outside the app: open index.html?mock in any browser.
if (!window.island) {
  const now = Date.now();
  const min = 60000;
  const listeners = {};
  const state = {
    claude: { state: 'idle', count: 0 },
    notifStatus: 'ok',
    bt: { supported: true, busy: false, error: null, devices: [
      { address: 'AABBCCDDEEFF', name: 'WH-1000XM4', connected: true, battery: 82 },
      { address: '112233445566', name: 'Keyboard K380', connected: true, battery: 12 },
      { address: '665544332211', name: 'JBL Flip 5', connected: false, battery: null } ] },
    timers: [{ id: 1, kind: 'timer', label: 'Tea', endAt: now + 4 * min + 12000 }, { id: 2, kind: 'alarm', time: '07:30', daily: true, endAt: now + 15 * 60 * min }],
    weather: { data: { temp: 29, feels: 33, hi: 32, lo: 24, icon: 'cloud-sun', label: 'Partly cloudy', city: 'Mumbai', units: 'c' }, error: null },
    requests: [],
    settings: { icsUrl: '', maxClips: 3, peekOnNotification: false, launchAtLogin: false },
    notes: 'Call vendor about invoice\n- ship v0.2\n- renew domain',
    pinned: false,
    media: { active: true, playing: true, title: 'Midnight City', artist: 'M83', art: null, muted: false, volume: 62, brightness: 70, source: 'chrome.exe' },
    calendar: {
      connected: true,
      events: [
        { title: 'Design review', start: now + 14 * min, end: now + 44 * min, joinUrl: 'https://meet.google.com/abc-defg-hij', location: '' },
        { title: 'Lunch with Priya', start: now + 150 * min, end: now + 210 * min, joinUrl: null, location: 'Blue Tokai' },
        { title: 'Sprint planning', start: now + 26 * 60 * min, end: now + 27 * 60 * min, joinUrl: 'https://zoom.us/j/123', location: '' },
      ],
    },
    notifications: [
      { id: 3, app: 'WhatsApp Desktop', kind: 'whatsapp', title: 'Priya', body: 'Are we still on for 1pm?', ts: now - 2 * min },
      { id: 2, app: 'Outlook', kind: 'mail', title: 'Invoice #2291 overdue', body: 'Hi, just a reminder that…', ts: now - 18 * min },
      { id: 1, app: 'Slack', kind: 'app', title: 'Rahul', body: 'merged your PR', ts: now - 55 * min },
    ],
    clips: [
      { id: 'a', type: 'text', text: 'https://carrypro.in/pricing?ref=newsletter', ts: now },
      { id: 'b', type: 'image', width: 1920, height: 1080, ts: now - 1000,
        thumb: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="220" height="140"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0a84ff"/><stop offset="1" stop-color="#bf5af2"/></linearGradient></defs><rect width="220" height="140" fill="url(#g)"/><rect x="18" y="20" width="120" height="10" rx="5" fill="#fff" opacity=".8"/><rect x="18" y="40" width="170" height="60" rx="8" fill="#fff" opacity=".25"/></svg>') },
      { id: 'c', type: 'text', text: 'Order #A-10442 shipped via Delhivery, arriving Thursday.', ts: now - 2000 },
    ],
  };
  window.island = {
    getState: async () => state,
    on: (ch, cb) => (listeners[ch] ||= []).push(cb),
    send: (ch, p) => console.log('[mock send]', ch, p),
  };
  window.__mockEmit = (ch, p) => (listeners[ch] || []).forEach((f) => f(p));
  document.addEventListener('DOMContentLoaded', () => setTimeout(() => window.__mockEmit('island:open', true), 50));
}
