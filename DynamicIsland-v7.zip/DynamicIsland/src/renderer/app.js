(() => {
  const $ = (id) => document.getElementById(id);
  const api = window.island;
  let S = null; // latest state snapshot

  // tiny DOM builder: text always goes through textContent (notification text is untrusted)
  function h(tag, props = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v; // only used with static SVG below
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v != null) el.setAttribute(k, v);
    }
    for (const kid of kids.flat()) if (kid) el.append(kid);
    return el;
  }
  const I = window.ICONS; // Lucide icons, see icons.js
  const ICON = { prev: I['skip-back'], next: I['skip-forward'], play: I.play, pause: I.pause, note: I.music, bolt: I.zap, x: I.x, copy: I.copy };
  document.querySelectorAll('[data-icon]').forEach((el) => (el.innerHTML = I[el.dataset.icon]));

  const fmtTime = (ms) => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const ago = (ms) => {
    const m = Math.round((Date.now() - ms) / 60000);
    if (m < 1) return 'now';
    if (m < 60) return `${m}m`;
    if (m < 1440) return `${Math.round(m / 60)}h`;
    return `${Math.round(m / 1440)}d`;
  };
  const dayLabel = (ms) => {
    const d = new Date(ms), t = new Date();
    const diff = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(t.getFullYear(), t.getMonth(), t.getDate())) / 86400000);
    return diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'short' });
  };
  const until = (ms) => {
    const m = Math.round((ms - Date.now()) / 60000);
    if (m <= 0) return 'Now';
    if (m < 60) return `in ${m} min`;
    return m < 1440 ? `in ${Math.floor(m / 60)}h ${m % 60}m` : dayLabel(ms);
  };

  /* ---------- tabs ---------- */
  function showTab(name, dir) {
    document.body.dataset.dir = dir || '';
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
    document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === `p-${name}`));
    if (name === 'alerts') { $('alertBadge').hidden = true; unread = { whatsapp: 0, mail: 0, app: 0 }; renderMini(); }
    if (name === 'notes') setTimeout(() => $('notes').focus(), 60);
    if (name === 'time') { renderTimers(); renderWeather(); tickTime(); }
    if (name === 'controls') { renderControls(); api.send('bt:refresh'); }
  }
  $('tabs').addEventListener('click', (e) => {
    const b = e.target.closest('.tab');
    if (b) showTab(b.dataset.tab);
  });

  /* ---------- music ---------- */
  function sourceName(src = '') {
    const s = src.toLowerCase();
    if (s.includes('chrome')) return 'Chrome';
    if (s.includes('msedge') || s.includes('edge')) return 'Edge';
    if (s.includes('firefox')) return 'Firefox';
    if (s.includes('brave')) return 'Brave';
    if (s.includes('opera')) return 'Opera';
    if (s.includes('spotify')) return 'Spotify';
    if (s.includes('applemusic') || s.includes('itunes')) return 'Apple Music';
    if (s.includes('vlc')) return 'VLC';
    return '';
  }
  function renderMusic() {
    const m = S.media;
    const box = $('music');
    box.replaceChildren();
    if (!m || !m.active) {
      box.append(h('div', { class: 'art', html: ICON.note }), h('div', { class: 'meta' }, h('div', { class: 'title', text: 'Nothing playing' }), h('div', { class: 'empty', text: 'Play something in Spotify, YouTube…' })));
      return;
    }
    const art = h('div', { class: 'art', html: m.art ? '' : ICON.note });
    if (m.art) art.style.backgroundImage = `url("${m.art}")`;
    const send = (c) => () => api.send('media:control', c);
    box.append(
      art,
      h('div', { class: 'meta' },
        h('div', { class: 'title', text: m.title || 'Unknown' }),
        h('div', { class: 'artist', text: [m.artist, sourceName(m.source)].filter(Boolean).join(' · ') }),
        h('div', { class: 'controls' },
          h('button', { html: ICON.prev, title: 'Previous', onclick: send('prev') }),
          h('button', { html: m.playing ? ICON.pause : ICON.play, title: 'Play / pause', onclick: send('toggle') }),
          h('button', { html: ICON.next, title: 'Next', onclick: send('next') }),
          h('div', { class: 'eq' + (m.playing ? ' playing' : '') }, h('i'), h('i'), h('i'), h('i')),
        ),
      ),
    );
  }

  /* ---------- idle pill ---------- */
  let claude = { state: 'idle' };
  let requests = [];
  let unread = { whatsapp: 0, mail: 0, app: 0 };
  let maxSeen = 0;
  let miniIdx = 0, miniTimer = null;
  let timers = [], weather = null, bt = null;
  const clockText = () => new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const fmtRem = (ms) => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
    return hh ? `${hh}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}` : `${mm}:${String(ss).padStart(2, '0')}`;
  };
  const trunc = (t, n) => (t.length > n ? t.slice(0, n - 1) + '…' : t);

  // what the pill can say right now, most important first
  function miniItems() {
    if (claude.state === 'working') return [{ kind: 'working', icon: 'bot', text: claude.count > 1 ? `Working ×${claude.count}` : 'Working' }];
    if (claude.state === 'waiting') return [{ kind: 'waiting', icon: 'bot', text: 'Needs you' }];
    if (claude.state === 'done') return [{ kind: 'done', icon: 'bot', text: claude.reply ? 'Reply?' : 'Done' }];
    const items = [];
    const total = unread.whatsapp + unread.mail + unread.app;
    if (total) {
      const latest = (S.notifications || [])[0];
      const kinds = ['whatsapp', 'mail', 'app'].filter((k) => unread[k]);
      const only = kinds.length === 1 ? kinds[0] : null;
      const icon = only === 'whatsapp' ? 'message-circle' : only === 'mail' ? 'mail' : 'bell-ring';
      const cls = only === 'whatsapp' ? 'wa' : only === 'mail' ? 'mail' : 'app';
      items.push({ kind: cls, icon, text: total === 1 && latest ? trunc(latest.title || latest.app, 16) : `${total} new` });
    }
    if (batt) {
      const pct = Math.round(batt.level * 100);
      if (!batt.charging && pct <= 20) items.push({ kind: 'low', icon: 'battery-low', text: `${pct}%` });
      else if (batt.charging && batt.level < 1) items.push({ kind: 'charging', icon: 'zap', text: `${pct}%` });
    }
    const m = S && S.media;
    if (m && m.muted) items.push({ kind: 'muted', icon: 'volume-x', text: 'Muted' });
    for (const d of (bt && bt.devices) || []) {
      if (!d.connected) continue;
      const low = d.battery != null && d.battery <= 15;
      items.push({ kind: low ? 'btlow' : 'bt', icon: 'headphones', text: d.battery != null ? `${trunc(d.name, 10)} ${d.battery}%` : trunc(d.name, 14) });
    }
    if (timers.length) {
      const t = timers[0];
      items.push({ kind: 'timer', icon: t.kind === 'alarm' ? 'alarm-clock' : 'timer', text: t.kind === 'alarm' ? t.time : fmtRem(t.endAt - Date.now()) });
    }
    if (m && m.active && m.playing && m.title) items.push({ kind: 'music', icon: 'music', art: m.art, text: trunc(m.title, 22) });
    if (weather && weather.data) items.push({ kind: 'weather', icon: weather.data.icon, text: `${weather.data.temp}°` });
    items.push({ kind: 'clock', icon: 'clock', text: clockText() });
    return items;
  }

  function paintMini(it) {
    const ico = $('miniIco');
    const kind = it ? it.kind : '';
    ico.className = 'mico ' + kind;
    if (it && it.art) ico.replaceChildren(h('img', { src: it.art, alt: '' }));
    else ico.innerHTML = it ? I[it.icon] : '';
    $('miniTxt').textContent = it ? it.text : '';
    // music keeps playing while something else is the main item: show its cover beside it
    const mm = S && S.media;
    const showExt = !!(it && it.kind !== 'music' && mm && mm.active && mm.playing);
    const ext = $('miniExt');
    ext.classList.toggle('on', showExt);
    if (showExt) { if (mm.art) ext.replaceChildren(h('img', { src: mm.art, alt: '' })); else ext.innerHTML = I.music; }
    else ext.replaceChildren();
    // size the pill to what is really inside it (fonts differ between machines)
    requestAnimationFrame(() => {
      const w = it ? Math.ceil($('miniIn').getBoundingClientRect().width) + 32 : 104;
      document.documentElement.style.setProperty('--pill-w', Math.min(Math.max(w, 96), 250) + 'px');
    });
  }

  function renderMini() {
    const items = miniItems();
    if (miniIdx >= items.length) miniIdx = 0;
    paintMini(items[miniIdx]);
    // several things to say: take turns (only while the island is closed)
    if (items.length > 1 && !miniTimer) {
      miniTimer = setInterval(() => {
        if (document.body.classList.contains('open')) return;
        const list = miniItems();
        if (list.length < 2) return;
        $('mini').classList.add('fade');
        setTimeout(() => { miniIdx = (miniIdx + 1) % list.length; paintMini(list[miniIdx]); $('mini').classList.remove('fade'); }, 170);
      }, 3500);
    } else if (items.length < 2 && miniTimer) { clearInterval(miniTimer); miniTimer = null; }
  }

  /* ---------- compact mode: Claude is working ---------- */
  let showAll = false, workingSince = null;
  const fmtDur = (ms) => { const s = Math.floor(ms / 1000); return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, '0')}s`; };
  function updateCompactMusic() {
    const m = S && S.media, box = $('cMusic');
    const on = !!(m && m.active && m.playing);
    box.hidden = !on;
    if (!on) return;
    box.title = [m.title, m.artist].filter(Boolean).join(' – ');
    if (m.art) box.replaceChildren(h('img', { src: m.art, alt: '' })); else box.innerHTML = I.music;
  }
  function renderCompact() {
    updateCompactMusic();
    if (workingSince) $('cSub').textContent = fmtDur(Date.now() - workingSince) + (claude.count > 1 ? ` · ${claude.count} sessions` : '');
  }
  function applyMode() {
    const compact = claude.state === 'working' && !showAll;
    document.body.classList.toggle('compact', compact);
    api.send('island:size', compact ? { w: 340, h: 84 } : { w: 540, h: 196 });
    if (compact) renderCompact();
  }
  function onClaude(c) {
    if (c.state === 'working' && claude.state !== 'working') workingSince = Date.now();
    if (c.state !== 'working') { workingSince = null; showAll = false; }
    claude = c;
    renderMini();
    applyMode();
  }
  $('cbot').innerHTML = I.bot;
  $('cMore').addEventListener('click', () => { showAll = true; applyMode(); });
  setInterval(() => document.body.classList.contains('compact') && document.body.classList.contains('open') && renderCompact(), 1000);

  /* ---------- Claude Code: approve / reply ---------- */
  const answer = (req, action, text) => {
    api.send('claude:answer', { id: req.id, action, text });
    requests = requests.filter((r) => r.id !== req.id);
    renderAsk();
  };
  function renderAsk() {
    const box = $('ask');
    const req = requests[0];
    box.hidden = !req;
    box.replaceChildren();
    if (!req) return;
    const head = h('div', { class: 'ask-head' }, h('span', { class: 'ask-bot', html: I.bot }),
      h('div', { class: 'grow' },
        h('div', { class: 't', text: req.kind === 'permission' ? `Claude wants to use ${req.tool}` : 'Claude finished' }),
        req.detail ? h('div', { class: req.kind === 'permission' ? 'code' : 'body-text', text: req.detail }) : null));
    if (req.kind === 'permission') {
      box.append(head, h('div', { class: 'ask-actions' },
        h('button', { class: 'btn ghost', text: 'Ask in terminal', onclick: () => answer(req, 'terminal') }),
        h('button', { class: 'btn deny', text: 'Deny', onclick: () => answer(req, 'deny') }),
        h('button', { class: 'btn allow', text: 'Allow', onclick: () => answer(req, 'allow') })));
    } else {
      const input = h('input', { type: 'text', placeholder: 'Reply to Claude…', maxlength: '2000' });
      const send = () => input.value.trim() && answer(req, 'reply', input.value);
      input.addEventListener('keydown', (e) => e.key === 'Enter' && send());
      box.append(head, h('div', { class: 'ask-actions' }, input,
        h('button', { class: 'btn allow icon', html: I.send, title: 'Send', onclick: send }),
        h('button', { class: 'btn ghost icon', html: I.x, title: 'Dismiss', onclick: () => answer(req, 'dismiss') })));
      setTimeout(() => input.focus(), 80);
    }
  }

  /* ---------- battery ---------- */
  let batt = null;
  function renderBattery() {
    renderMini();
    const box = $('battery');
    box.replaceChildren();
    if (!batt) return box.append(h('div', { class: 'sub', text: 'Battery unavailable' }));
    const pct = Math.round(batt.level * 100);
    const noBattery = batt.charging && batt.level === 1 && batt.chargingTime === 0;
    const fill = h('div', { class: 'batt-fill' });
    fill.style.transform = `scaleX(${batt.level})`;
    if (!batt.charging && pct <= 20) fill.style.background = 'var(--red)';
    const icon = h('div', { class: 'batt-icon' }, fill, batt.charging ? h('span', { html: ICON.bolt }) : null);
    if (batt.charging) icon.lastChild.style.display = 'contents';
    const secs = batt.charging ? batt.chargingTime : batt.dischargingTime;
    const left = Number.isFinite(secs) && secs > 0 ? ` · ${Math.floor(secs / 3600)}h ${Math.round((secs % 3600) / 60)}m` : '';
    box.append(icon, h('div', {},
      h('div', { class: 'big', text: noBattery ? 'Plugged in' : `${pct}%` }),
      noBattery ? null : h('div', { class: 'sub', text: (batt.charging ? 'Charging' : 'On battery') + left }),
    ));
  }
  if (navigator.getBattery) {
    navigator.getBattery().then((b) => {
      batt = b;
      ['levelchange', 'chargingchange', 'chargingtimechange', 'dischargingtimechange'].forEach((ev) => b.addEventListener(ev, renderBattery));
      renderBattery();
    });
  } else renderBattery();

  /* ---------- calendar ---------- */
  function upcoming() {
    return (S.calendar?.events || []).filter((e) => e.end > Date.now());
  }
  function renderNext() {
    const box = $('nextMeeting');
    box.replaceChildren();
    const ev = upcoming()[0];
    if (!S.calendar?.connected) return box.append(h('div', { class: 'sub', text: 'Add a calendar in ⚙ settings' }));
    if (!ev) return box.append(h('div', { class: 'when', text: 'Calendar' }), h('div', { class: 't', text: 'No meetings coming up' }));
    box.append(h('div', { class: 'when', text: ev.start <= Date.now() ? 'Happening now' : until(ev.start) }), h('div', { class: 't', text: ev.title }), h('div', { class: 'sub', text: ev.allDay ? 'All day' : `${fmtTime(ev.start)} – ${fmtTime(ev.end)}` }));
  }
  function renderAgenda() {
    const box = $('agenda');
    box.replaceChildren();
    if (!S.calendar?.connected) return box.append(h('div', { class: 'placeholder', text: 'No calendar connected. Open ⚙ settings and paste your calendar’s .ics link.' }));
    if (S.calendar.error) box.append(h('div', { class: 'day', text: S.calendar.error }));
    const evs = upcoming();
    if (!evs.length) return box.append(h('div', { class: 'placeholder', text: 'Nothing scheduled for the next 7 days 🎉' }));
    let last = '';
    for (const ev of evs) {
      const d = dayLabel(ev.start);
      if (d !== last) box.append(h('div', { class: 'day', text: (last = d) }));
      box.append(h('div', { class: 'row-item' },
        h('div', { class: 'time', text: ev.allDay ? 'All day' : fmtTime(ev.start) }),
        h('div', { class: 'grow' }, h('div', { class: 't', text: ev.title }), ev.location ? h('div', { class: 'body-text', text: ev.location }) : null),
        ev.joinUrl ? h('button', { class: 'join', text: 'Join', onclick: () => api.send('cal:join', ev.joinUrl) }) : null,
      ));
    }
  }

  /* ---------- notifications ---------- */
  const hue = (str) => [...str].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
  function badgeEl(n) {
    const el = h('div', { class: `app-badge ${n.kind}` });
    if (n.kind === 'whatsapp') el.innerHTML = I['message-circle'];
    else if (n.kind === 'mail') el.innerHTML = I.mail;
    else { el.textContent = (n.app || '?').slice(0, 1).toUpperCase(); el.style.background = `hsl(${hue(n.app || '?')} 45% 38%)`; }
    return el;
  }
  const KINDS = [['all', 'All'], ['whatsapp', 'WhatsApp'], ['mail', 'Mail'], ['app', 'Apps']];
  let alertFilter = 'all';
  const STATUS_TEXT = {
    starting: 'Listening for notifications…',
    ok: 'No new notifications',
    'no-db': 'Windows notification history wasn’t found on this PC.',
    'no-sqlite': 'Notification reading isn’t available in this build.',
    error: 'Couldn’t read notifications just now. Retrying…',
  };
  function renderAlerts() {
    const box = $('alertList');
    box.replaceChildren();
    const all = S.notifications || [];
    $('clearAlerts').hidden = !all.length;
    const count = (k) => (k === 'all' ? all.length : all.filter((n) => n.kind === k).length);
    $('alertChips').replaceChildren(...KINDS.map(([k, label]) =>
      h('button', { class: 'chip' + (alertFilter === k ? ' on' : ''), onclick: () => { alertFilter = k; renderAlerts(); } },
        label, count(k) ? h('b', { text: String(count(k)) }) : null)));
    const items = alertFilter === 'all' ? all : all.filter((n) => n.kind === alertFilter);
    if (!items.length) return box.append(h('div', { class: 'placeholder', text: all.length ? 'Nothing here' : STATUS_TEXT[S.notifStatus] || STATUS_TEXT.ok }));
    for (const n of items) {
      box.append(h('div', { class: 'row-item' },
        badgeEl(n),
        h('div', { class: 'grow' }, h('div', { class: 't', text: n.title || n.app }), h('div', { class: 'body-text', text: n.body })),
        h('div', { class: 'ago', text: ago(n.ts) }),
        h('button', { class: 'x', html: ICON.x, title: 'Dismiss', onclick: () => api.send('notif:dismiss', n.id) }),
      ));
    }
  }
  function badge() {
    if (!document.getElementById('p-alerts').classList.contains('active')) $('alertBadge').hidden = false;
  }
  $('clearAlerts').addEventListener('click', () => { api.send('notif:clear'); unread = { whatsapp: 0, mail: 0, app: 0 }; renderMini(); });

  /* ---------- clipboard ---------- */
  function renderClips() {
    const box = $('clipList');
    box.replaceChildren();
    const clips = S.clips || [];
    box.style.gridTemplateColumns = `repeat(${S.settings.maxClips}, 1fr)`;
    if (!clips.length) {
      box.style.gridTemplateColumns = '1fr';
      return box.append(h('div', { class: 'placeholder', text: 'Copy text or take a screenshot (Win + Shift + S) and it shows up here. Drag items into any app.' }));
    }
    for (const c of clips) {
      const acts = h('div', { class: 'acts' },
        h('button', { html: ICON.copy, title: 'Copy again', onclick: (e) => { e.stopPropagation(); api.send('clip:copy', c.id); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 500); } }),
        h('button', { html: ICON.x, title: 'Remove', onclick: (e) => { e.stopPropagation(); api.send('clip:remove', c.id); } }),
      );
      const el = h('div', { class: `clip ${c.type}`, draggable: 'true' },
        c.type === 'text' ? h('div', { class: 'snippet', text: c.text }) : h('span', { class: 'tag', text: `${c.width}×${c.height}` }),
        acts,
      );
      if (c.type === 'image') el.style.backgroundImage = `url("${c.thumb}")`;
      el.addEventListener('click', () => { api.send('clip:copy', c.id); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 500); });
      el.addEventListener('dragstart', (e) => {
        api.send('drag:lock', true);
        if (c.type === 'image') { e.preventDefault(); api.send('clip:drag', c.id); } // native file drag
        else { e.dataTransfer.setData('text/plain', c.text); e.dataTransfer.effectAllowed = 'copy'; }
      });
      el.addEventListener('dragend', () => api.send('drag:lock', false));
      box.append(el);
    }
  }
  // native drags don't always fire dragend; release the lock on the next mouse movement
  let dragging = false;
  document.addEventListener('dragstart', () => (dragging = true), true);
  document.addEventListener('mousemove', () => { if (dragging) { dragging = false; api.send('drag:lock', false); } }, true);

  // keep the island open while you're typing, even if the mouse wanders off
  const isField = (el) => el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT');
  document.addEventListener('focusin', (e) => isField(e.target) && api.send('edit:lock', true));
  document.addEventListener('focusout', (e) => isField(e.target) && api.send('edit:lock', false));

  /* ---------- notes ---------- */
  let noteTimer;
  $('notes').addEventListener('input', () => {
    clearTimeout(noteTimer);
    noteTimer = setTimeout(() => {
      api.send('notes:set', $('notes').value);
      $('saved').textContent = 'Saved';
      $('saved').classList.add('show');
      setTimeout(() => $('saved').classList.remove('show'), 1200);
    }, 350);
  });

  /* ---------- settings / pin ---------- */
  let settingsOpen = false;
  function toggleSettings(v = !settingsOpen) {
    settingsOpen = v;
    $('p-settings').classList.toggle('active', v);
    $('gearBtn').classList.toggle('on', v);
  }
  $('gearBtn').addEventListener('click', () => toggleSettings());
  $('icsUrl').addEventListener('change', (e) => api.send('settings:set', { icsUrl: e.target.value }));
  $('optLogin').addEventListener('change', (e) => api.send('settings:set', { launchAtLogin: e.target.checked }));
  $('optPeek').addEventListener('change', (e) => api.send('settings:set', { peekOnNotification: e.target.checked }));
  $('optClips').addEventListener('change', (e) => {
    S.settings.maxClips = +e.target.value;
    api.send('settings:set', { maxClips: +e.target.value });
    renderClips();
  });
  $('optPill').addEventListener('change', (e) => {
    document.body.classList.toggle('pill', e.target.checked);
    api.send('settings:set', { idlePill: e.target.checked });
  });
  $('wxCity').addEventListener('change', (e) => api.send('settings:set', { weatherCity: e.target.value }));
  $('wxUnits').addEventListener('change', (e) => api.send('settings:set', { units: e.target.value }));
  $('quitBtn').addEventListener('click', () => api.send('app:quit'));
  let pinned = false;
  const setPin = (v) => { pinned = v; $('pinBtn').classList.toggle('on', v); };
  $('pinBtn').addEventListener('click', () => { setPin(!pinned); api.send('pin:set', pinned); });

  /* ---------- peek ---------- */
  function peek(n) {
    const p = $('peek');
    p.replaceChildren(
      badgeEl(n),
      h('div', { class: 'grow' }, h('div', { class: 't', text: n.title || n.app }), h('div', { class: 'body-text', text: n.body })),
    );
    p.hidden = false;
    setTimeout(() => (p.hidden = true), 4300);
  }

  /* ---------- mute ---------- */
  function renderMute() {
    const m = S.media;
    const btn = $('muteBtn');
    btn.hidden = !m || m.muted == null;
    btn.classList.toggle('on', !!(m && m.muted));
    btn.innerHTML = I[m && m.muted ? 'volume-x' : 'volume-2'];
  }
  $('muteBtn').addEventListener('click', () => api.send('media:control', 'mute'));

  /* ---------- clock, weather, timers ---------- */
  const remSpans = new Map();
  function tickTime() {
    const d = new Date();
    $('clockTime').textContent = clockText();
    $('clockDate').textContent = d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'short' });
    for (const [id, span] of remSpans) {
      const t = timers.find((x) => x.id === id);
      if (t) span.textContent = fmtRem(t.endAt - Date.now());
    }
  }
  function renderWeather() {
    const box = $('wx');
    box.replaceChildren();
    const w = weather;
    if (!w || (!w.data && !w.error)) return box.append(h('div', { class: 'sub', text: 'Loading weather…' }));
    if (!w.data) return box.append(h('div', { class: 'sub', text: w.error + ' · check ⚙ settings' }));
    const d = w.data;
    box.append(h('span', { html: I[d.icon] }),
      h('div', { class: 'temp', text: `${d.temp}°` }),
      h('div', { class: 'grow' }, h('div', { class: 't', text: d.label }), h('div', { class: 'sub', text: `${d.city || ''} · H ${d.hi}° L ${d.lo}°` })));
  }
  function renderTimers() {
    const box = $('tList');
    box.replaceChildren();
    remSpans.clear();
    if (!timers.length) return box.append(h('div', { class: 'tempty', text: 'No timers or alarms' }));
    for (const t of timers) {
      const rem = h('span', { class: 'rem' });
      remSpans.set(t.id, rem);
      const name = t.kind === 'alarm' ? `Alarm ${t.time}${t.daily ? ' · daily' : ''}` : t.label || 'Timer';
      box.append(h('div', { class: 'titem' },
        h('span', { html: I[t.kind === 'alarm' ? 'alarm-clock' : 'timer'] }),
        h('span', { class: 'lbl', text: name }), rem,
        h('button', { class: 'x', html: ICON.x, title: 'Cancel', onclick: () => api.send('timer:remove', t.id) })));
    }
    tickTime();
  }
  document.querySelectorAll('[data-min]').forEach((b) => b.addEventListener('click', () => api.send('timer:add', { kind: 'timer', minutes: +b.dataset.min })));
  $('tmGo').addEventListener('click', () => { const v = +$('tmMin').value; if (v > 0) { api.send('timer:add', { kind: 'timer', minutes: v }); $('tmMin').value = ''; } });
  $('tmMin').addEventListener('keydown', (e) => e.key === 'Enter' && $('tmGo').click());
  $('alGo').addEventListener('click', () => { const t = $('alTime').value; if (t) api.send('timer:add', { kind: 'alarm', time: t, daily: $('alDaily').checked }); });

  // alarm / timer ringing
  let audioCtx = null, beepTimer = null, beepStop = null;
  function stopBeep() { clearInterval(beepTimer); clearTimeout(beepStop); beepTimer = beepStop = null; }
  function startBeep() {
    stopBeep();
    try {
      audioCtx = audioCtx || new AudioContext();
      audioCtx.resume && audioCtx.resume();
      const beep = () => {
        const t = audioCtx.currentTime, o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = 'sine'; o.frequency.value = 880;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
        o.connect(g); g.connect(audioCtx.destination); o.start(t); o.stop(t + 0.2);
      };
      const burst = () => [0, 250, 500].forEach((d) => setTimeout(beep, d));
      burst();
      beepTimer = setInterval(burst, 1600);
      beepStop = setTimeout(stopBeep, 60000);
    } catch {}
  }
  function ring(t) {
    const card = $('alarmCard');
    const done = () => { stopBeep(); card.hidden = true; api.send('alarm:ack'); };
    card.replaceChildren(
      h('div', { class: 'ask-head' }, h('span', { class: 'ask-bot', html: I['bell-ring'] }),
        h('div', { class: 'grow' }, h('div', { class: 't', text: t.kind === 'alarm' ? `Alarm · ${t.time}` : 'Timer finished' }), t.label ? h('div', { class: 'body-text', text: t.label }) : null)),
      h('div', { class: 'ask-actions' },
        h('button', { class: 'btn ghost', text: 'Snooze 5 min', onclick: () => { api.send('timer:add', { kind: 'timer', minutes: 5, label: t.label || (t.kind === 'alarm' ? `Alarm ${t.time}` : '') }); done(); } }),
        h('button', { class: 'btn allow', text: 'Dismiss', onclick: done })));
    card.hidden = false;
    startBeep();
  }

  // 1 s heartbeat: live countdowns on the open Time tab, and the idle pill while closed
  let lastMinute = -1;
  setInterval(() => {
    const open = document.body.classList.contains('open');
    if (open) { if ($('p-time').classList.contains('active')) tickTime(); return; }
    const min = Math.floor(Date.now() / 60000);
    if (timers.length || min !== lastMinute) { lastMinute = min; renderMini(); }
  }, 1000);

  /* ---------- controls: volume, brightness, Bluetooth ---------- */
  const fill = (el) => el.style.setProperty('--v', ((el.value - el.min) / (el.max - el.min)) * 100 + '%');
  let dragUntil = 0;
  const throttled = (fn, ms) => { let t = 0; return (...a) => { const n = Date.now(); if (n - t >= ms) { t = n; fn(...a); } }; };
  const sendVol = throttled((v) => api.send('media:control', `vol:${v}`), 90);
  const sendBri = throttled((v) => api.send('media:control', `bright:${v}`), 150);
  function renderControls() {
    const m = S.media || {};
    const busy = Date.now() < dragUntil; // don't fight the slider while it is being moved
    if (!busy) {
      if (m.volume != null) { $('volRange').value = m.volume; $('volPct').textContent = m.muted ? 'Muted' : m.volume + '%'; fill($('volRange')); }
      if (m.brightness != null) { $('briRange').value = m.brightness; $('briPct').textContent = m.brightness + '%'; fill($('briRange')); }
    }
    const noBri = m.brightness == null && m.volume != null; // helper is running but panel brightness is unavailable
    $('briRow').style.opacity = noBri ? .35 : 1;
    $('briRange').disabled = noBri;
    $('briHint').hidden = !noBri;
    $('ctlMute').classList.toggle('on', !!m.muted);
    $('ctlMute').innerHTML = I[m.muted ? 'volume-x' : 'volume-2'];
    renderBt();
  }
  $('volRange').addEventListener('input', (e) => { dragUntil = Date.now() + 700; fill(e.target); $('volPct').textContent = e.target.value + '%'; sendVol(e.target.value); });
  $('briRange').addEventListener('input', (e) => { dragUntil = Date.now() + 900; fill(e.target); $('briPct').textContent = e.target.value + '%'; sendBri(e.target.value); });
  $('volRange').addEventListener('change', (e) => api.send('media:control', `vol:${e.target.value}`));
  $('briRange').addEventListener('change', (e) => api.send('media:control', `bright:${e.target.value}`));
  $('ctlMute').addEventListener('click', () => api.send('media:control', 'mute'));

  function renderBt() {
    const box = $('btList');
    box.replaceChildren();
    $('btRefresh').classList.toggle('spin', !!(bt && bt.busy));
    if (!bt || !bt.supported) return box.append(h('div', { class: 'tempty', text: 'Bluetooth is only available on Windows' }));
    if (bt.error && !bt.devices.length) return box.append(h('div', { class: 'tempty', text: bt.error }));
    if (!bt.devices.length) return box.append(h('div', { class: 'tempty', text: bt.busy ? 'Looking for devices…' : 'No paired devices. Use + to add one.' }));
    for (const d of bt.devices) {
      const row = h('div', { class: 'btdev ' + (d.connected ? 'on' : 'off'), title: d.connected ? 'Click to disconnect' : 'Click to connect' },
        h('span', { html: I[d.connected ? 'bluetooth-connected' : 'bluetooth'] }),
        h('span', { class: 'nm', text: d.name }),
        d.battery != null ? h('span', { class: 'bat' + (d.battery <= 15 ? ' low' : ''), text: d.battery + '%' }) : null,
        h('span', { class: 'state', text: bt.busy ? '…' : d.connected ? 'Connected' : 'Connect' }));
      row.addEventListener('click', () => !bt.busy && api.send('bt:toggle', { address: d.address, connect: !d.connected }));
      box.append(row);
    }
  }
  $('btRefresh').addEventListener('click', () => api.send('bt:refresh'));
  $('btAdd').addEventListener('click', () => api.send('bt:add'));

  /* ---------- swipe / scroll sideways to change tab ---------- */
  const tabNames = () => [...document.querySelectorAll('.tab')].map((b) => b.dataset.tab);
  function stepTab(dir) {
    const names = tabNames();
    const cur = names.indexOf(document.querySelector('.tab.active').dataset.tab);
    const next = cur + dir;
    if (next < 0 || next >= names.length) return;
    toggleSettings(false);
    showTab(names[next], dir > 0 ? 'next' : 'prev');
  }
  let sw = null;
  $('shell').addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('input,textarea,select,button,.chips,[draggable=true]')) return;
    sw = { x: e.clientX, y: e.clientY };
  });
  window.addEventListener('pointerup', (e) => {
    if (!sw) return;
    const dx = e.clientX - sw.x, dy = e.clientY - sw.y;
    sw = null;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.8) stepTab(dx < 0 ? 1 : -1);
  });
  let wheelLock = 0;
  $('shell').addEventListener('wheel', (e) => {
    if (Math.abs(e.deltaX) < 25 || Math.abs(e.deltaX) < Math.abs(e.deltaY) || Date.now() < wheelLock) return;
    wheelLock = Date.now() + 450;
    stepTab(e.deltaX > 0 ? 1 : -1);
  }, { passive: true });

  /* ---------- wiring ---------- */
  function renderAll() {
    renderMusic(); renderBattery(); renderNext(); renderAgenda(); renderAlerts(); renderClips();
  }
  api.on('island:open', (open) => {
    document.body.classList.toggle('open', open);
    if (open) { renderNext(); renderAgenda(); renderAlerts(); renderBattery(); }
    else { toggleSettings(false); $('peek').hidden = true; showAll = false; applyMode(); if (!pinned) showTab('now'); }
  });
  api.on('island:pinned', setPin);
  api.on('island:peek', peek);
  api.on('media', (m) => { S.media = m; renderMusic(); renderMute(); renderMini(); if ($('p-controls').classList.contains('active')) renderControls(); updateCompactMusic(); });
  api.on('bt', (b) => { bt = b; renderMini(); if ($('p-controls').classList.contains('active')) renderBt(); });
  api.on('timers', (t) => { timers = t; renderTimers(); renderMini(); });
  api.on('weather', (w) => { weather = w; renderWeather(); renderMini(); });
  api.on('timer:fire', ring);
  api.on('claude', onClaude);
  api.on('notif:status', (st) => { S.notifStatus = st; renderAlerts(); });
  api.on('claude:request', (r) => { requests.push(r); renderAsk(); });
  api.on('claude:request-end', (id) => { requests = requests.filter((r) => r.id !== id); renderAsk(); });
  api.on('clips', (c) => { S.clips = c; renderClips(); });
  api.on('notifications', (n) => {
    S.notifications = n;
    const viewing = document.body.classList.contains('open') && $('p-alerts').classList.contains('active');
    for (const x of n) if (x.id > maxSeen) { maxSeen = x.id; if (!viewing) unread[x.kind] = (unread[x.kind] || 0) + 1; }
    renderAlerts();
    if (!viewing && Object.values(unread).some(Boolean)) badge();
    renderMini();
  });
  api.on('calendar', (c) => { S.calendar = c; renderNext(); renderAgenda(); });
  setInterval(() => document.body.classList.contains('open') && (renderNext(), renderAlerts()), 30000);

  api.getState().then((s) => {
    S = s;
    $('notes').value = s.notes || '';
    $('icsUrl').value = s.settings.icsUrl || '';
    $('optLogin').checked = s.settings.launchAtLogin;
    $('optPeek').checked = s.settings.peekOnNotification;
    $('optPill').checked = s.settings.idlePill;
    document.body.classList.toggle('pill', s.settings.idlePill);
    bt = s.bt || null;
    timers = s.timers || [];
    weather = s.weather || null;
    $('wxCity').value = s.settings.weatherCity || '';
    $('wxUnits').value = s.settings.units || 'c';
    renderMute();
    renderTimers();
    renderWeather();
    claude = s.claude || claude;
    if (claude.state === 'working') workingSince = Date.now();
    maxSeen = Math.max(0, ...(s.notifications || []).map((x) => x.id));
    requests = s.requests || [];
    renderMini();
    applyMode();
    renderAsk();
    $('optClips').value = String(s.settings.maxClips);
    setPin(s.pinned);
    renderAll();
  });
})();
