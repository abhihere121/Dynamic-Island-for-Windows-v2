// Reads Windows toast notifications (WhatsApp, Outlook/Mail, Chrome web
// notifications, anything that shows a banner) from the notification database
// that Windows itself maintains. Read-only, no accounts or passwords involved.
const { EventEmitter } = require('events');
const fs = require('fs');
const os = require('os');
const path = require('path');

const decode = (s) =>
  s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
    .replace(/&amp;/g, '&')
    .trim();

function parsePayload(payload) {
  const xml = Buffer.isBuffer(payload) || payload instanceof Uint8Array
    ? Buffer.from(payload).toString('utf8').replace(/^﻿/, '')
    : String(payload);
  const texts = [];
  const re = /<text\b([^>]*)>([\s\S]*?)<\/text>/g;
  let m;
  while ((m = re.exec(xml))) {
    if (/placement\s*=\s*["']attribution["']/.test(m[1])) continue;
    const t = decode(m[2]);
    if (t) texts.push(t);
  }
  return { title: texts[0] || '', body: texts.slice(1).join('\n') };
}

function appName(primaryId = '') {
  let id = primaryId.split('!')[0];
  if (id.includes('_')) id = id.split('_')[0]; // package family -> name
  id = id.split('.').pop();
  id = path.basename(id.replace(/\\/g, '/')).replace(/\.exe$/i, '');
  return id.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/Whats App/, 'WhatsApp') || 'App';
}

function classify(primaryId, title, body) {
  const hay = `${primaryId} ${title} ${body}`.toLowerCase();
  if (hay.includes('whatsapp')) return 'whatsapp';
  if (/outlook|microsoft\.windowscommunicationsapps|thunderbird|mail\.google|gmail|proton|yahoo.*mail|spark|mailbird|em ?client|zoho.*mail|\bmail\b|inbox/.test(hay))
    return 'mail';
  return 'app';
}

const FILETIME_EPOCH_OFFSET_MS = 11644473600000;
const fileTimeToMs = (ft) => Number(BigInt(ft) / 10000n) - FILETIME_EPOCH_OFFSET_MS;

class NotificationWatcher extends EventEmitter {
  constructor({ dbPath, tmpDir, max = 30 }) {
    super();
    this.dbPath =
      dbPath ||
      path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'Windows', 'Notifications', 'wpndatabase.db');
    this.tmpDir = tmpDir || fs.mkdtempSync(path.join(os.tmpdir(), 'island-wpn-'));
    this.max = max;
    this.items = [];
    this.lastId = null;
    this.status = 'starting'; // starting | ok | no-db | no-sqlite | error
  }

  _status(s) {
    if (s === this.status) return;
    this.status = s;
    this.emit('status', s);
  }

  start() {
    this.poll();
    this.timer = setInterval(() => this.poll(), 3000);
  }

  stop() {
    clearInterval(this.timer);
  }

  list() {
    return this.items;
  }

  clear() {
    this.items = [];
    this.emit('change', this.items);
  }

  dismiss(id) {
    this.items = this.items.filter((n) => n.id !== id);
    this.emit('change', this.items);
  }

  poll() {
    if (!fs.existsSync(this.dbPath)) return this._status('no-db');
    let DatabaseSync;
    try {
      ({ DatabaseSync } = require('node:sqlite'));
    } catch {
      return this._status('no-sqlite'); // runtime without node:sqlite
    }
    const copy = path.join(this.tmpDir, 'wpn.db');
    try {
      // Skip all work unless Windows actually wrote to the DB or its WAL since last time.
      const sig = ['', '-wal'].map((e) => {
        try {
          const st = fs.statSync(this.dbPath + e);
          return `${st.size}:${st.mtimeMs}`;
        } catch {
          return '-';
        }
      }).join('|');
      if (sig === this.lastSig) return;
      this.lastSig = sig;
      // The live DB is locked and in WAL mode: work on a private copy with its WAL.
      for (const ext of ['', '-wal', '-shm']) {
        const src = this.dbPath + ext;
        if (fs.existsSync(src)) fs.copyFileSync(src, copy + ext);
        else fs.rmSync(copy + ext, { force: true });
      }
      const db = new DatabaseSync(copy);
      try {
        if (this.lastId === null) {
          this.lastId = Number(db.prepare('SELECT COALESCE(MAX(Id),0) AS m FROM Notification').get().m);
          this._status('ok');
          return; // start from "now", don't replay history
        }
        this._status('ok');
        const stmt = db
          .prepare(
            `SELECT n.Id, n.Payload, n.ArrivalTime, h.PrimaryId
               FROM Notification n LEFT JOIN NotificationHandler h ON h.RecordId = n.HandlerId
              WHERE n.Id > ? AND n.Type = 'toast' ORDER BY n.Id`,
          );
        stmt.setReadBigInts(true);
        const rows = stmt.all(BigInt(this.lastId));
        const fresh = [];
        for (const r of rows) {
          const id = Number(r.Id);
          this.lastId = Math.max(this.lastId, id);
          const { title, body } = parsePayload(r.Payload);
          if (!title && !body) continue;
          fresh.push({
            id,
            app: appName(r.PrimaryId),
            kind: classify(r.PrimaryId || '', title, body),
            title,
            body,
            ts: r.ArrivalTime ? fileTimeToMs(r.ArrivalTime) : Date.now(),
          });
        }
        if (fresh.length) {
          this.items = [...fresh.reverse(), ...this.items].slice(0, this.max);
          this.emit('change', this.items);
          this.emit('new', fresh);
        }
      } finally {
        db.close();
      }
    } catch (e) {
      this._status('error');
      if (process.env.ISLAND_DEBUG) console.error(e);
    }
  }
}

module.exports = { NotificationWatcher, parsePayload, appName, classify };
