// Current weather from Open-Meteo (free, no API key). Location: the city typed in
// settings, or an approximate one from your IP address if left blank.
const { EventEmitter } = require('events');

const get = async (url) => {
  const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
};

// WMO weather codes -> Lucide icon + label
function describe(code, isDay) {
  if (code === 0) return { icon: isDay ? 'sun' : 'moon', label: 'Clear' };
  if (code <= 2) return { icon: isDay ? 'cloud-sun' : 'cloud-moon', label: 'Partly cloudy' };
  if (code === 3) return { icon: 'cloud', label: 'Overcast' };
  if (code === 45 || code === 48) return { icon: 'cloud-fog', label: 'Fog' };
  if (code >= 51 && code <= 57) return { icon: 'cloud-drizzle', label: 'Drizzle' };
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return { icon: 'cloud-rain', label: 'Rain' };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { icon: 'cloud-snow', label: 'Snow' };
  if (code >= 95) return { icon: 'cloud-lightning', label: 'Thunderstorm' };
  return { icon: 'cloud', label: 'Cloudy' };
}

class WeatherWatcher extends EventEmitter {
  constructor() {
    super();
    this.city = '';
    this.units = 'c';
    this.data = null;
    this.error = null;
    this.loc = null;
  }

  start() {
    this.timer = setInterval(() => this.refresh(), 30 * 60 * 1000);
    this.refresh();
  }

  stop() {
    clearInterval(this.timer);
  }

  setConfig({ city, units }) {
    const next = { city: (city ?? this.city).trim(), units: units === undefined ? this.units : units === 'f' ? 'f' : 'c' };
    const moved = next.city !== this.city;
    Object.assign(this, next);
    if (moved) this.loc = null;
    this.refresh();
  }

  snapshot() {
    return { data: this.data, error: this.error };
  }

  async locate() {
    if (this.loc) return this.loc;
    if (this.city) {
      const g = await get(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(this.city)}&count=1`);
      const r = g.results && g.results[0];
      if (!r) throw new Error('City not found');
      return (this.loc = { lat: r.latitude, lon: r.longitude, name: r.name });
    }
    const ip = await get('https://ipwho.is/');
    if (!ip.success) throw new Error('Could not detect location');
    return (this.loc = { lat: ip.latitude, lon: ip.longitude, name: ip.city });
  }

  async refresh() {
    try {
      const loc = await this.locate();
      const unit = this.units === 'f' ? 'fahrenheit' : 'celsius';
      const j = await get(
        `https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}` +
          `&current=temperature_2m,apparent_temperature,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min` +
          `&temperature_unit=${unit}&timezone=auto&forecast_days=1`,
      );
      this.data = WeatherWatcher.parse(j, loc.name, this.units);
      this.error = null;
    } catch (e) {
      this.error = e.message === 'City not found' ? 'City not found' : 'Weather unavailable';
    }
    this.emit('change', this.snapshot());
  }

  static parse(j, city, units) {
    const c = j.current;
    const d = describe(c.weather_code, c.is_day === 1);
    return {
      temp: Math.round(c.temperature_2m),
      feels: Math.round(c.apparent_temperature),
      hi: Math.round(j.daily.temperature_2m_max[0]),
      lo: Math.round(j.daily.temperature_2m_min[0]),
      icon: d.icon,
      label: d.label,
      city,
      units,
    };
  }
}

module.exports = { WeatherWatcher, describe };
