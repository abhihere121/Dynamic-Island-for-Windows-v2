# Bridges Windows' System Media Transport Controls (Spotify, YouTube in Chrome/Edge,
# Apple Music, VLC, ...) and the master volume/mute to the island. Prints one JSON line
# whenever state changes and executes commands dropped into the command file:
#   toggle | next | prev | mute | vol:<0-100> | bright:<1-100>
param([string]$CmdFile)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime

# master volume / mute through the Windows Core Audio COM API
$audioOk = $true
try {
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
  int f(); int g(); int h(); int i();
  int SetMasterVolumeLevelScalar(float fLevel, Guid pguidEventContext);
  int j();
  int GetMasterVolumeLevelScalar(out float pfLevel);
  int k(); int l(); int m(); int n();
  int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, Guid pguidEventContext);
  int GetMute(out bool pbMute);
}
[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice { int Activate(ref Guid id, int clsCtx, int activationParams, out IAudioEndpointVolume aev); }
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator { int f(); int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint); }
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorComObject { }
public class IslandAudio {
  static IAudioEndpointVolume Vol() {
    var e = new MMDeviceEnumeratorComObject() as IMMDeviceEnumerator;
    IMMDevice dev = null;
    Marshal.ThrowExceptionForHR(e.GetDefaultAudioEndpoint(0, 1, out dev));
    IAudioEndpointVolume epv = null;
    var id = typeof(IAudioEndpointVolume).GUID;
    Marshal.ThrowExceptionForHR(dev.Activate(ref id, 23, 0, out epv));
    return epv;
  }
  public static float Volume {
    get { float v = -1; Marshal.ThrowExceptionForHR(Vol().GetMasterVolumeLevelScalar(out v)); return v; }
    set { Marshal.ThrowExceptionForHR(Vol().SetMasterVolumeLevelScalar(value, Guid.Empty)); }
  }
  public static bool Mute {
    get { bool m; Marshal.ThrowExceptionForHR(Vol().GetMute(out m)); return m; }
    set { Marshal.ThrowExceptionForHR(Vol().SetMute(value, Guid.Empty)); }
  }
}
'@
} catch { $audioOk = $false }

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]
function Await($op, $type) {
  $task = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op))
  if (-not $task.Wait(5000)) { throw 'timeout' }
  $task.Result
}

$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]

# Album art as a data: URI. Two ways of reading the stream; failures are logged to %TEMP%\island-media.log
function Get-Art($thumb) {
  try {
    $rs = Await ($thumb.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
    $mime = if ($rs.ContentType) { $rs.ContentType } else { 'image/jpeg' }
    $bytes = $null
    try {
      $ms = New-Object IO.MemoryStream
      [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($rs).CopyTo($ms)
      if ($ms.Length -gt 0) { $bytes = $ms.ToArray() }
    } catch { Add-Content (Join-Path $env:TEMP 'island-media.log') ('art(stream): ' + $_.Exception.Message) }
    if (-not $bytes -and $rs.Size -gt 0) {
      $rs.Seek(0)
      $reader = New-Object Windows.Storage.Streams.DataReader($rs)
      $n = [uint32]$rs.Size
      $null = Await ($reader.LoadAsync($n)) ([uint32])
      $bytes = New-Object byte[] $n
      $reader.ReadBytes($bytes)
    }
    if ($bytes -and $bytes.Length -gt 0 -and $bytes.Length -lt 1500000) {
      return 'data:' + $mime + ';base64,' + [Convert]::ToBase64String($bytes)
    }
  } catch { Add-Content (Join-Path $env:TEMP 'island-media.log') ('art: ' + $_.Exception.Message) }
  return $null
}
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])

# laptop panel brightness (WMI). External monitors don't expose this; then brightness stays null.
$brightOk = $true
$brightness = $null
function Get-Brightness {
  try { return [int](Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction Stop | Select-Object -First 1).CurrentBrightness }
  catch { return $null }
}
function Set-Brightness([int]$n) {
  Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods -ErrorAction Stop |
    Invoke-CimMethod -MethodName WmiSetBrightness -Arguments @{ Timeout = [uint32]1; Brightness = [byte]$n } | Out-Null
}
$brightTick = 0

$lastJson = ''
$lastTrack = ''
$art = $null
$artTries = 0
$tick = 0
$force = $true

while ($true) {
  try {
    $s = $mgr.GetCurrentSession()

    if ($CmdFile -and (Test-Path $CmdFile)) {
      $cmd = (Get-Content $CmdFile -Raw).Trim()
      Remove-Item $CmdFile -Force
      switch -Regex ($cmd) {
        '^toggle$' { if ($s) { $null = $s.TryTogglePlayPauseAsync() } }
        '^next$'   { if ($s) { $null = $s.TrySkipNextAsync() } }
        '^prev$'   { if ($s) { $null = $s.TrySkipPreviousAsync() } }
        '^mute$'   { if ($audioOk) { [IslandAudio]::Mute = -not [IslandAudio]::Mute } }
        '^vol:(\d+)$' { if ($audioOk) { [IslandAudio]::Volume = [math]::Min(100, [int]$Matches[1]) / 100 } }
        '^bright:(\d+)$' { if ($brightOk) { Set-Brightness ([math]::Max(1, [math]::Min(100, [int]$Matches[1]))); $brightTick = 0 } }
      }
      $force = $true
      Start-Sleep -Milliseconds 250   # let the player react before re-reading
    }

    # Commands are checked every 250 ms (cheap file test); the WinRT reads only every ~1 s.
    $tick++
    if (-not $force -and ($tick % 4) -ne 0) { Start-Sleep -Milliseconds 250; continue }
    $force = $false

    if ($s) {
      $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
      $track = "$($p.Title)|$($p.Artist)"
      if ($track -ne $lastTrack) { $lastTrack = $track; $art = $null; $artTries = 0 }
      # players often publish the cover a moment after the title: keep trying for a few polls
      if (-not $art -and $p.Thumbnail -and $artTries -lt 6) { $artTries++; $art = Get-Art $p.Thumbnail }
      $status = $s.GetPlaybackInfo().PlaybackStatus.ToString()
      $state = [ordered]@{
        active  = $true
        title   = $p.Title
        artist  = $p.Artist
        playing = ($status -eq 'Playing')
        art     = $art
        source  = $s.SourceAppUserModelId
      }
    } else {
      $lastTrack = ''
      $state = [ordered]@{ active = $false }
    }

    $muted = $null
    $volume = $null
    if ($audioOk) {
      try { $muted = [IslandAudio]::Mute; $volume = [int][math]::Round([IslandAudio]::Volume * 100) } catch { $muted = $null }
    }
    $state['muted'] = $muted
    $state['volume'] = $volume

    # brightness: WMI is slow, so only look every ~6 s (and right after a change)
    if ($brightOk -and ($brightTick % 6) -eq 0) {
      $b = Get-Brightness
      if ($null -eq $b -and $null -eq $brightness) { $brightOk = $false } else { $brightness = $b }
    }
    $brightTick++
    $state['brightness'] = $brightness

    $json = $state | ConvertTo-Json -Compress
    if ($json -ne $lastJson) {
      $lastJson = $json
      [Console]::Out.WriteLine($json)
      [Console]::Out.Flush()
    }
  } catch {
    # session churn (player closed mid-read) - just retry
  }
  Start-Sleep -Milliseconds 250
}
