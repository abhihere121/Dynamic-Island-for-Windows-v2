# Paired Bluetooth devices with connection state and battery, and connect / disconnect.
#   bluetooth.ps1 list
#   bluetooth.ps1 connect <12-hex-digit address>
#   bluetooth.ps1 disconnect <12-hex-digit address>
param([string]$Action = 'list', [string]$Address = '')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

function Get-Devices {
  $found = @{}
  Get-PnpDevice -Class Bluetooth -ErrorAction SilentlyContinue | ForEach-Object {
    # the device node itself, not its per-service child nodes
    if ($_.InstanceId -match '^(BTHENUM|BTHLE)\\DEV_([0-9A-Fa-f]{12})\\') {
      $addr = $Matches[2].ToUpper()
      $conn = $null; $bat = $null
      try { $conn = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName '{83DA6326-97A6-4088-9453-A1923F573B29} 15' -ErrorAction Stop).Data } catch {}
      try { $bat  = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2'  -ErrorAction Stop).Data } catch {}
      $item = [ordered]@{
        address   = $addr
        name      = $_.FriendlyName
        connected = [bool]$conn
        battery   = $(if ($null -ne $bat) { [int]$bat } else { $null })
      }
      $prev = $found[$addr]
      # a device can appear as both classic and LE: keep whichever knows more
      if (-not $prev -or ($item.connected -and -not $prev.connected) -or ($null -ne $item.battery -and $null -eq $prev.battery)) {
        $found[$addr] = $item
      }
    }
  }
  ConvertTo-Json -InputObject @($found.Values) -Compress
}

if ($Action -eq 'list') { Get-Devices; exit 0 }

# connect / disconnect: enable or disable the device's audio services through the Win32 Bluetooth API
if ($Address -notmatch '^[0-9A-Fa-f]{12}$') { Write-Output '{"ok":false,"error":"bad address"}'; exit 1 }
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class IslandBt {
  [StructLayout(LayoutKind.Sequential)]
  public struct SYSTEMTIME { public ushort a, b, c, d, e, f, g, h; }
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct DEVINFO {
    public uint dwSize; public ulong Address; public uint ulClassofDevice;
    public int fConnected; public int fRemembered; public int fAuthenticated;
    public SYSTEMTIME stLastSeen; public SYSTEMTIME stLastUsed;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 248)] public string szName;
  }
  [StructLayout(LayoutKind.Sequential)]
  public struct SEARCH {
    public uint dwSize; public int fReturnAuthenticated; public int fReturnRemembered; public int fReturnUnknown;
    public int fReturnConnected; public int fIssueInquiry; public byte cTimeoutMultiplier; public IntPtr hRadio;
  }
  [DllImport("bthprops.cpl", SetLastError = true)] static extern IntPtr BluetoothFindFirstDevice(ref SEARCH p, ref DEVINFO d);
  [DllImport("bthprops.cpl", SetLastError = true)] static extern bool BluetoothFindNextDevice(IntPtr h, ref DEVINFO d);
  [DllImport("bthprops.cpl", SetLastError = true)] static extern bool BluetoothFindDeviceClose(IntPtr h);
  [DllImport("bthprops.cpl", SetLastError = true)] static extern uint BluetoothSetServiceState(IntPtr radio, ref DEVINFO d, ref Guid svc, uint flags);

  static readonly Guid[] Services = {
    new Guid("0000110B-0000-1000-8000-00805F9B34FB"), // A2DP sink (stereo audio)
    new Guid("0000111E-0000-1000-8000-00805F9B34FB"), // hands-free
    new Guid("00001108-0000-1000-8000-00805F9B34FB"), // headset
    new Guid("0000110E-0000-1000-8000-00805F9B34FB")  // AVRCP (media buttons)
  };

  // returns 0 on success, 1 if the device was not found, otherwise a Win32 error code
  public static uint Apply(ulong address, bool enable) {
    var d = new DEVINFO(); d.dwSize = (uint)Marshal.SizeOf(typeof(DEVINFO));
    var s = new SEARCH(); s.dwSize = (uint)Marshal.SizeOf(typeof(SEARCH));
    s.fReturnAuthenticated = 1; s.fReturnRemembered = 1; s.fReturnConnected = 1;
    IntPtr h = BluetoothFindFirstDevice(ref s, ref d);
    if (h == IntPtr.Zero) return 1;
    try {
      do {
        if (d.Address == address) {
          uint worst = 0;
          foreach (var g in Services) {
            var guid = g;
            uint r = BluetoothSetServiceState(IntPtr.Zero, ref d, ref guid, enable ? 1u : 0u);
            if (r != 0 && worst == 0) worst = r;
          }
          return worst;
        }
      } while (BluetoothFindNextDevice(h, ref d));
    } finally { BluetoothFindDeviceClose(h); }
    return 1;
  }
}
'@
$addr = [Convert]::ToUInt64($Address, 16)
if ($Action -eq 'disconnect') {
  $r = [IslandBt]::Apply($addr, $false)
} else {
  # off then on makes Windows re-establish the link
  [void][IslandBt]::Apply($addr, $false)
  Start-Sleep -Milliseconds 600
  $r = [IslandBt]::Apply($addr, $true)
}
if ($r -eq 0) { Write-Output '{"ok":true}' } else { Write-Output ('{"ok":false,"error":"code ' + $r + '"}') }
