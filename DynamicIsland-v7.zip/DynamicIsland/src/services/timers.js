// Countdown timers and (optionally daily) alarms. Persisted so they survive a restart.
// The 1 s tick only runs while at least one timer exists.
const { EventEmitter } = require('events');

const DAY = 86400000;

function nextOccurrence(hhmm, now = Date.now()) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(hhmm || '');
  if (!m) return null;
  const d = new Date(now);
  d.setHours(+m[1], +m[2], 0, 0);
  if (+d <= now) d.setTime(+d + DAY);
  return +d;
}

class TimerService extends EventEmitter {
  constructor(store) {
    super();
    this.store = store;
    this.seq = Date.now();
    this.items = (store.get('timers') || []).filter((t) => t && t.endAt);
  }

  start() {
    this.check(true);
    this.arm();
  }

  stop() {
    clearInterval(this.t);
  }

  arm() {
    clearInterval(this.t);
    this.t = this.items.length ? setInterval(() => this.check(), 1000) : null;
  }

  save() {
    this.store.set({ timers: this.items });
  }

  // fire what is due; on startup only things that are less than a minute late still ring
  check(startup = false) {
    const now = Date.now();
    const keep = [];
    let changed = false;
    for (const it of this.items) {
      if (it.endAt > now) {
        keep.push(it);
        continue;
      }
      changed = true;
      if (!startup || now - it.endAt < 60000) this.emit('fire', it);
      if (it.daily && it.time) keep.push({ ...it, endAt: nextOccurrence(it.time, now) });
    }
    if (changed) {
      this.items = keep;
      this.save();
      this.arm();
      this.emit('change', this.list());
    }
  }

  add({ kind, minutes, time, label, daily }) {
    const now = Date.now();
    let endAt;
    if (kind === 'alarm') endAt = nextOccurrence(time, now);
    else endAt = now + Math.min(Math.max(Math.round(+minutes) || 0, 1), 999) * 60000;
    if (!endAt) return;
    this.items.push({
      id: ++this.seq,
      kind: kind === 'alarm' ? 'alarm' : 'timer',
      label: String(label || '').slice(0, 40),
      endAt,
      time: kind === 'alarm' ? time : undefined,
      daily: kind === 'alarm' && !!daily,
    });
    this.items.sort((a, b) => a.endAt - b.endAt);
    this.save();
    this.arm();
    this.emit('change', this.list());
  }

  remove(id) {
    this.items = this.items.filter((t) => t.id !== id);
    this.save();
    this.arm();
    this.emit('change', this.list());
  }

  list() {
    return this.items;
  }
}

module.exports = { TimerService, nextOccurrence };
