const ical = require('node-ical');
const { EventEmitter } = require('events');

const JOIN_RE =
  /https?:\/\/(?:[\w-]+\.)?(?:zoom\.us|zoom\.com|meet\.google\.com|teams\.microsoft\.com|teams\.live\.com|webex\.com|whereby\.com)\/[^\s"<>)]+/i;

const DAY = 86400000;

function expand(events, from, to) {
  const out = [];
  const push = (ev, start, end) => {
    if (end < from || start > to) return;
    const text = `${ev.location || ''} ${ev.description || ''}`;
    out.push({
      title: String(ev.summary?.val ?? ev.summary ?? '(No title)'),
      start: start.getTime(),
      end: end.getTime(),
      allDay: ev.datetype === 'date',
      location: String(ev.location?.val ?? ev.location ?? ''),
      joinUrl: (text.match(JOIN_RE) || [])[0] || null,
    });
  };

  for (const ev of events) {
    if (ev.type !== 'VEVENT' || !ev.start) continue;
    const dur = ev.end ? ev.end - ev.start : 0;
    if (ev.rrule) {
      const skip = new Set(Object.values(ev.exdate || {}).map((d) => +d));
      for (const d of ev.rrule.between(new Date(+from - dur), to, true)) {
        if (skip.has(+d)) continue;
        const override = ev.recurrences?.[d.toISOString().slice(0, 10)];
        if (override) push(override, override.start, override.end);
        else push(ev, d, new Date(+d + dur));
      }
    } else {
      push(ev, ev.start, ev.end || ev.start);
    }
  }
  return out.sort((a, b) => a.start - b.start);
}

class CalendarWatcher extends EventEmitter {
  constructor() {
    super();
    this.url = '';
    this.events = [];
    this.error = null;
  }

  setUrl(url) {
    this.url = (url || '').trim().replace(/^webcal:/i, 'https:');
    this.refresh();
  }

  start() {
    this.timer = setInterval(() => this.refresh(), 10 * 60 * 1000);
    this.refresh();
  }

  stop() {
    clearInterval(this.timer);
  }

  snapshot() {
    return { connected: !!this.url, error: this.error, events: this.events };
  }

  async refresh() {
    if (!this.url) {
      this.events = [];
      this.error = null;
      return this.emit('change', this.snapshot());
    }
    try {
      const data = await ical.async.fromURL(this.url);
      const now = new Date();
      this.events = expand(Object.values(data), new Date(+now - 3600000), new Date(+now + 7 * DAY))
        .filter((e) => e.end > +now)
        .slice(0, 25);
      this.error = null;
    } catch (e) {
      this.error = 'Could not load calendar';
    }
    this.emit('change', this.snapshot());
  }
}

module.exports = { CalendarWatcher, expand };
