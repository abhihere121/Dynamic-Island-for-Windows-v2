// Local endpoint (127.0.0.1 only) that Claude Code hooks talk to. It powers the idle
// pill status and lets you answer from the island:
//   /claude/working|done|waiting  status pings
//   /claude/permission            holds a permission prompt until you Allow/Deny
//   /claude/stop-reply            holds briefly after a turn so you can type a reply
// The hook's stdout is the response body, which is how an answer reaches Claude Code.
// No answer in time -> empty body -> Claude Code carries on exactly as normal.
const http = require('http');
const { EventEmitter } = require('events');

const STALE_MS = 30 * 60 * 1000;
const DONE_MS = 8000;
const HOLD_MS = { permission: 25000, reply: 9000 };

const describe = (input = {}) =>
  String(input.command || input.file_path || input.url || input.pattern || JSON.stringify(input)).slice(0, 220);

class ClaudeWatcher extends EventEmitter {
  constructor(port = 47821) {
    super();
    this.port = port;
    this.sessions = new Map();
    this.pending = new Map();
    this.seq = 0;
    this.last = '';
  }

  start() {
    this.server = http.createServer((req, res) => {
      const m = req.method === 'POST' && /^\/claude\/(working|done|waiting|permission|stop-reply)$/.exec(req.url);
      if (!m) {
        res.statusCode = 404;
        return res.end();
      }
      let body = '';
      req.on('data', (d) => {
        body += d;
        if (body.length > 262144) req.destroy();
      });
      req.on('end', () => {
        let j = {};
        try {
          j = JSON.parse(body);
        } catch {}
        const kind = m[1];
        if (kind === 'permission' || kind === 'stop-reply') return this.hold(kind === 'permission' ? 'permission' : 'reply', j, res);
        this.update(kind, j);
        res.end('ok');
      });
    });
    this.server.on('error', () => {}); // port busy: the pill just won't show Claude status
    this.server.listen(this.port, '127.0.0.1');
    this.timer = setInterval(() => this.publish(), 3000);
  }

  stop() {
    clearInterval(this.timer);
    this.server?.close();
  }

  update(state, j = {}) {
    this.sessions.set(String(j.session_id || 'default'), { state, ts: Date.now() });
    this.publish();
  }

  hold(kind, j, res) {
    const id = ++this.seq;
    const session = String(j.session_id || 'default');
    const info =
      kind === 'permission'
        ? { id, kind, session, tool: j.tool_name || 'a tool', detail: describe(j.tool_input) }
        : { id, kind, session, detail: String(j.last_assistant_message || '').slice(0, 200) };
    const finish = (answer) => {
      if (!this.pending.has(id)) return;
      clearTimeout(timer);
      this.pending.delete(id);
      res.setHeader('Content-Type', 'application/json');
      res.end(answer ? JSON.stringify(answer) : '');
      this.emit('request-end', id);
      this.publish();
    };
    const timer = setTimeout(() => finish(null), HOLD_MS[kind]);
    res.on('close', () => finish(null)); // hook process went away
    this.pending.set(id, { info, finish });
    this.update(kind === 'permission' ? 'waiting' : 'done', j);
    this.emit('request', info);
  }

  answer(id, action, text) {
    const p = this.pending.get(id);
    if (!p) return;
    const { info, finish } = p;
    if (info.kind === 'permission') {
      if (action === 'allow') {
        this.update('working', { session_id: info.session });
        return finish({ hookSpecificOutput: { hookEventName: 'PermissionRequest', decision: { behavior: 'allow' } } });
      }
      if (action === 'deny') {
        return finish({
          hookSpecificOutput: {
            hookEventName: 'PermissionRequest',
            decision: { behavior: 'deny', message: 'Denied from Dynamic Island' },
          },
        });
      }
      return finish(null); // "ask in terminal"
    }
    const reply = String(text || '').trim().slice(0, 4000);
    if (action === 'reply' && reply) {
      this.update('working', { session_id: info.session });
      return finish({ decision: 'block', reason: `The user replied from Dynamic Island: ${reply}` });
    }
    finish(null);
  }

  requests() {
    return [...this.pending.values()].map((p) => p.info);
  }

  summary() {
    const now = Date.now();
    let working = 0, waiting = 0, done = false;
    for (const [id, s] of this.sessions) {
      const age = now - s.ts;
      if (age > STALE_MS) this.sessions.delete(id);
      else if (s.state === 'working') working++;
      else if (s.state === 'waiting') waiting++;
      else if (age < DONE_MS) done = true;
    }
    const reply = this.requests().some((r) => r.kind === 'reply');
    if (waiting) return { state: 'waiting', count: waiting, reply: false };
    if (working) return { state: 'working', count: working, reply: false };
    if (done || reply) return { state: 'done', count: 1, reply };
    return { state: 'idle', count: 0, reply: false };
  }

  publish() {
    const s = this.summary();
    const key = JSON.stringify(s);
    if (key === this.last) return;
    this.last = key;
    this.emit('change', s);
  }
}

module.exports = { ClaudeWatcher };
