const { EventEmitter } = require('events');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

class MediaWatcher extends EventEmitter {
  constructor({ dir }) {
    super();
    this.dir = dir;
    this.state = { active: false };
    this.cmdFile = path.join(dir, 'media-cmd.txt');
  }

  start() {
    if (process.platform !== 'win32') return;
    fs.mkdirSync(this.dir, { recursive: true });
    // Copy out of the asar so powershell can execute it.
    const script = path.join(this.dir, 'media.ps1');
    fs.copyFileSync(path.join(__dirname, 'media.ps1'), script);

    this.proc = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-CmdFile', this.cmdFile],
      { windowsHide: true },
    );
    let buf = '';
    this.proc.stdout.on('data', (d) => {
      buf += d.toString('utf8');
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        try {
          this.state = JSON.parse(line);
          this.emit('change', this.state);
        } catch {}
      }
    });
    this.proc.on('exit', () => {
      this.proc = null;
      setTimeout(() => this.start(), 5000); // restart if it dies
    });
  }

  stop() {
    const p = this.proc;
    this.proc = null;
    p?.removeAllListeners('exit');
    p?.kill();
  }

  control(cmd) {
    if (!['toggle', 'next', 'prev', 'mute'].includes(cmd) && !/^(vol|bright):\d{1,3}$/.test(cmd)) return;
    try {
      fs.writeFileSync(this.cmdFile, cmd);
    } catch {}
  }
}

module.exports = { MediaWatcher };
