// Paired Bluetooth devices (connection state + battery) via a small PowerShell script.
// It is spawned on demand, never kept running: once at start, then every 5 minutes, and
// whenever the Controls tab asks for a refresh.
const { EventEmitter } = require('events');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

function parseDevices(text) {
  let arr;
  try {
    arr = JSON.parse(String(text).trim() || '[]');
  } catch {
    return null;
  }
  if (!Array.isArray(arr)) arr = [arr];
  return arr
    .filter((d) => d && /^[0-9A-F]{12}$/i.test(d.address || ''))
    .map((d) => ({
      address: d.address.toUpperCase(),
      name: String(d.name || 'Bluetooth device').slice(0, 40),
      connected: !!d.connected,
      battery: Number.isFinite(d.battery) && d.battery >= 0 && d.battery <= 100 ? Math.round(d.battery) : null,
    }))
    .sort((a, b) => b.connected - a.connected || a.name.localeCompare(b.name));
}

class BluetoothWatcher extends EventEmitter {
  constructor({ dir }) {
    super();
    this.dir = dir;
    this.devices = [];
    this.busy = false;
    this.error = null;
    this.supported = process.platform === 'win32';
  }

  start() {
    if (!this.supported) return;
    fs.mkdirSync(this.dir, { recursive: true });
    this.script = path.join(this.dir, 'bluetooth.ps1');
    fs.copyFileSync(path.join(__dirname, 'bluetooth.ps1'), this.script);
    this.refresh();
    this.timer = setInterval(() => this.refresh(), 5 * 60 * 1000);
  }

  stop() {
    clearInterval(this.timer);
  }

  snapshot() {
    return { devices: this.devices, busy: this.busy, error: this.error, supported: this.supported };
  }

  run(args) {
    return new Promise((resolve, reject) => {
      const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', this.script, ...args], { windowsHide: true });
      let out = '';
      const kill = setTimeout(() => p.kill(), 25000);
      p.stdout.on('data', (d) => (out += d));
      p.on('error', (e) => { clearTimeout(kill); reject(e); });
      p.on('exit', () => { clearTimeout(kill); resolve(out); });
    });
  }

  async refresh() {
    if (!this.supported || this.busy) return;
    this.busy = true;
    this.emit('change', this.snapshot());
    try {
      const list = parseDevices(await this.run(['list']));
      if (list) { this.devices = list; this.error = null; } else this.error = 'Could not read devices';
    } catch {
      this.error = 'Could not read devices';
    }
    this.busy = false;
    this.emit('change', this.snapshot());
  }

  async toggle(address, connect) {
    if (!this.supported || this.busy || !/^[0-9A-F]{12}$/i.test(address)) return;
    this.busy = true;
    this.emit('change', this.snapshot());
    try {
      await this.run([connect ? 'connect' : 'disconnect', address.toUpperCase()]);
      await new Promise((r) => setTimeout(r, 1500)); // give Windows a moment to settle
    } catch {}
    this.busy = false;
    await this.refresh();
  }
}

module.exports = { BluetoothWatcher, parseDevices };
