const fs = require('fs');
const path = require('path');

const DEFAULTS = {
  icsUrl: '',
  maxClips: 3,
  peekOnNotification: false,
  idlePill: true,
  timers: [],
  weatherCity: '',
  units: 'c',
  notes: '',
};

class Store {
  constructor(dir) {
    this.file = path.join(dir, 'settings.json');
    this.data = { ...DEFAULTS };
    try {
      Object.assign(this.data, JSON.parse(fs.readFileSync(this.file, 'utf8')));
    } catch {}
    this._t = null;
  }

  get(key) {
    return this.data[key];
  }

  set(patch) {
    Object.assign(this.data, patch);
    clearTimeout(this._t);
    this._t = setTimeout(() => this.flush(), 400);
  }

  flush() {
    clearTimeout(this._t);
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
    } catch (e) {
      console.error('settings save failed', e);
    }
  }
}

module.exports = { Store };
