const { clipboard, nativeImage } = require('electron');
const { EventEmitter } = require('events');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Polls the system clipboard and keeps the last few items. Text lives in memory
// only; images (including Win+Shift+S screenshots) are written to a temp dir so
// they can be dragged out as real files.
class ClipboardWatcher extends EventEmitter {
  constructor({ dir, max = 3 }) {
    super();
    this.dir = dir;
    this.max = max;
    this.items = [];
    this.lastKey = null;
    fs.mkdirSync(dir, { recursive: true });
  }

  start() {
    this.lastKey = this._signature(); // ignore whatever is already on the clipboard
    this.timer = setInterval(() => this._poll(), 1000);
  }

  stop() {
    clearInterval(this.timer);
    for (const f of fs.readdirSync(this.dir)) fs.rmSync(path.join(this.dir, f), { force: true });
  }

  setMax(n) {
    this.max = n;
    this._trim();
    this.emit('change', this.list());
  }

  // Cheap change detection: text is compared directly; images are only decoded when
  // the clipboard actually advertises one, and hashed from a sparse sample of pixels.
  _hasImage() {
    return clipboard.availableFormats().some((f) => f.startsWith('image/'));
  }

  _imageKey(img) {
    const bmp = img.toBitmap();
    const h = crypto.createHash('md5');
    h.update(String(bmp.length));
    for (let i = 0; i < bmp.length; i += 997) h.update(bmp.subarray(i, i + 4));
    return 'i:' + h.digest('hex');
  }

  _signature() {
    if (this._hasImage()) {
      const img = clipboard.readImage();
      if (!img.isEmpty()) return this._imageKey(img);
    }
    const text = clipboard.readText();
    return text.trim() ? 't:' + text.slice(0, 4000) : null;
  }

  _poll() {
    let key, item;
    if (this._hasImage()) {
      const img = clipboard.readImage();
      if (!img.isEmpty()) {
        key = this._imageKey(img);
        if (key === this.lastKey) return;
        item = this._imageItem(key, img);
      }
    }
    if (!item) {
      const text = clipboard.readText();
      if (!text.trim()) return;
      key = 't:' + text.slice(0, 4000);
      if (key === this.lastKey) return;
      item = { id: crypto.createHash('md5').update(text).digest('hex'), type: 'text', text: text.slice(0, 4000), ts: Date.now() };
    }
    this.lastKey = key;
    this._add(item);
  }

  _imageItem(id, img) {
    const file = path.join(this.dir, `Screenshot-${Date.now()}.png`);
    fs.writeFileSync(file, img.toPNG());
    const { width, height } = img.getSize();
    const thumb = img.resize({ width: 220 }).toDataURL();
    return { id, type: 'image', file, thumb, width, height, ts: Date.now() };
  }

  _add(item) {
    const dup = this.items.findIndex((i) => i.id === item.id);
    if (dup >= 0) this._drop(this.items.splice(dup, 1)[0]);
    this.items.unshift(item);
    this._trim();
    this.emit('change', this.list());
  }

  _trim() {
    while (this.items.length > this.max) this._drop(this.items.pop());
  }

  _drop(item) {
    if (item.file) fs.rmSync(item.file, { force: true });
  }

  list() {
    return this.items.map(({ file, ...rest }) => rest);
  }

  find(id) {
    return this.items.find((i) => i.id === id);
  }

  remove(id) {
    const i = this.items.findIndex((x) => x.id === id);
    if (i < 0) return;
    this._drop(this.items.splice(i, 1)[0]);
    this.emit('change', this.list());
  }

  copyBack(id) {
    const item = this.find(id);
    if (!item) return;
    if (item.type === 'text') clipboard.writeText(item.text);
    else clipboard.writeImage(nativeImage.createFromPath(item.file));
    this.lastKey = item.type === 'text' ? 't:' + item.text : item.id;
  }

  dragIcon(id) {
    const item = this.find(id);
    if (!item || item.type !== 'image') return null;
    return nativeImage.createFromPath(item.file).resize({ width: 64 });
  }
}

module.exports = { ClipboardWatcher };
