const { app, BrowserWindow, ipcMain, screen, shell, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const { Store } = require('./services/store');
const { ClipboardWatcher } = require('./services/clipboard');
const { NotificationWatcher } = require('./services/notifications');
const { CalendarWatcher } = require('./services/calendar');
const { MediaWatcher } = require('./services/media');
const { ClaudeWatcher } = require('./services/claude');
const { TimerService } = require('./services/timers');
const { WeatherWatcher } = require('./services/weather');
const { BluetoothWatcher } = require('./services/bluetooth');

// Window is larger than the island so the open animation and shadow have room.
const WIN = { w: 620, h: 250 };
const ISLAND = { w: 540, h: 196, top: 8 };
const HOT = { w: 260, h: 4 }; // invisible strip at the top-centre edge of the screen
const PILL = { w: 260, h: 42 }; // hover area around the resting pill
const CLOSE_DELAY = 450;

// Light footprint, but GPU compositing stays on so the animation is smooth.
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=48');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion,MediaRouter,Translate');

if (!app.requestSingleInstanceLock()) app.quit();

function setAutoStart(on) {
  // Unpackaged (npm start) needs to relaunch electron with the app path.
  app.setLoginItemSettings(
    app.isPackaged
      ? { openAtLogin: on }
      : { openAtLogin: on, path: process.execPath, args: [app.getAppPath()] },
  );
}

let quitting = false;
let isl = { w: ISLAND.w, h: ISLAND.h }; // current island size (renderer reports compact mode)
let win, tray, store, clips, notifs, cal, media, claude, timers, weather, bt;
let alarmLock = false; // an alarm is ringing: stay open until dismissed
let open = false;
let pinned = false;
let dragLock = false;
let editLock = false; // a text field has focus (notes, reply, settings)
let holdUntil = 0; // keep open until this time (notification peek)
let closeTimer = null;

function place() {
  if (!win || win.isDestroyed()) return;
  const { x, y, width } = screen.getPrimaryDisplay().bounds;
  win.setBounds({ x: x + Math.round((width - WIN.w) / 2), y, width: WIN.w, height: WIN.h });
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function setOpen(next) {
  if (quitting || !win || win.isDestroyed()) return;
  if (open === next) return;
  open = next;
  clearTimeout(closeTimer);
  closeTimer = null;
  if (open) {
    win.setFocusable(true);
    win.setIgnoreMouseEvents(false);
  } else {
    editLock = false;
    win.setIgnoreMouseEvents(true); // clicks pass through to the apps underneath
    if (win.isFocused()) win.blur();
    win.setFocusable(false);
  }
  send('island:open', open);
}

// The window is transparent and click-through while closed, so the browser never
// sees the pointer. Track the cursor from the main process instead.
function tick() {
  if (quitting || !win || win.isDestroyed()) return;
  const p = screen.getCursorScreenPoint();
  const b = win.getBounds();
  const cx = b.x + b.width / 2;
  const hot = store.get('idlePill') ? PILL : HOT;
  const inHot = p.y <= b.y + hot.h && Math.abs(p.x - cx) <= hot.w / 2;
  if (!open) {
    if (inHot) setOpen(true);
    return;
  }
  const inIsland =
    p.y >= b.y && p.y <= b.y + ISLAND.top + isl.h + 20 && Math.abs(p.x - cx) <= isl.w / 2 + 20;
  if (inIsland || inHot || pinned || dragLock || editLock || alarmLock || claude.pending.size || Date.now() < holdUntil) {
    clearTimeout(closeTimer);
    closeTimer = null;
  } else if (!closeTimer) {
    closeTimer = setTimeout(() => setOpen(false), CLOSE_DELAY);
  }
}

function snapshot() {
  return {
    settings: {
      icsUrl: store.get('icsUrl'),
      maxClips: store.get('maxClips'),
      peekOnNotification: store.get('peekOnNotification'),
      idlePill: store.get('idlePill'),
      weatherCity: store.get('weatherCity'),
      units: store.get('units'),
      launchAtLogin: app.getLoginItemSettings().openAtLogin,
    },
    notes: store.get('notes'),
    clips: clips.list(),
    notifications: notifs.list(),
    notifStatus: notifs.status,
    calendar: cal.snapshot(),
    media: media.state,
    claude: claude.summary(),
    timers: timers.list(),
    bt: bt.snapshot(),
    weather: weather.snapshot(),
    requests: claude.requests(),
    pinned,
  };
}

function createWindow() {
  win = new BrowserWindow({
    width: WIN.w,
    height: WIN.h,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    skipTaskbar: true,
    hasShadow: false,
    show: false,
    focusable: false,
    type: 'toolbar', // tool window: never gets a taskbar button or Alt-Tab entry
    alwaysOnTop: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      autoplayPolicy: 'no-user-gesture-required', // alarm sound must play without a click
      sandbox: true,
    },
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces?.(true);
  win.setIgnoreMouseEvents(true);
  place();
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => {
    win.showInactive();
    win.setSkipTaskbar(true);
  });
  win.on('blur', () => {
    editLock = false; // clicked elsewhere: stop holding the island open
  });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  screen.on('display-metrics-changed', place);
  screen.on('display-added', place);
  screen.on('display-removed', place);
}

function createTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, '..', 'assets', 'icon.png')).resize({ width: 16 });
  tray = new Tray(icon);
  tray.setToolTip('Dynamic Island — hover the top-centre of your screen');
  const menu = () =>
    Menu.buildFromTemplate([
      { label: pinned ? 'Unpin island' : 'Pin island open', click: () => setPinned(!pinned) },
      {
        label: 'Launch at login',
        type: 'checkbox',
        checked: app.getLoginItemSettings().openAtLogin,
        click: (i) => setAutoStart(i.checked),
      },
      { type: 'separator' },
      { label: 'Quit', click: () => app.quit() },
    ]);
  tray.on('click', () => setPinned(!pinned));
  tray.on('right-click', () => tray.popUpContextMenu(menu()));
}

function setPinned(v) {
  pinned = v;
  if (pinned) setOpen(true);
  send('island:pinned', pinned);
}

function wireIpc() {
  ipcMain.handle('state:get', () => snapshot());

  ipcMain.on('media:control', (_, cmd) => media.control(cmd));

  ipcMain.on('clip:copy', (_, id) => clips.copyBack(id));
  ipcMain.on('clip:remove', (_, id) => clips.remove(id));
  ipcMain.on('clip:drag', (e, id) => {
    const item = clips.find(id);
    const icon = clips.dragIcon(id);
    if (item?.file && icon) e.sender.startDrag({ file: item.file, icon });
  });
  ipcMain.on('island:size', (_, s) => {
    isl = { w: Math.min(Math.max(+s.w || ISLAND.w, 200), ISLAND.w), h: Math.min(Math.max(+s.h || ISLAND.h, 60), ISLAND.h) };
  });
  ipcMain.on('edit:lock', (_, v) => {
    editLock = !!v;
  });
  ipcMain.on('drag:lock', (_, v) => {
    dragLock = !!v;
  });

  ipcMain.on('notes:set', (_, text) => store.set({ notes: String(text).slice(0, 20000) }));
  ipcMain.on('notif:clear', () => notifs.clear());
  ipcMain.on('notif:dismiss', (_, id) => notifs.dismiss(id));

  ipcMain.on('cal:join', (_, url) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url);
  });

  ipcMain.on('pin:set', (_, v) => setPinned(!!v));

  ipcMain.on('settings:set', (_, patch) => {
    const next = {};
    if (typeof patch.icsUrl === 'string') {
      next.icsUrl = patch.icsUrl.trim();
      cal.setUrl(next.icsUrl);
    }
    if ([2, 3].includes(patch.maxClips)) {
      next.maxClips = patch.maxClips;
      clips.setMax(patch.maxClips);
    }
    if (typeof patch.peekOnNotification === 'boolean') next.peekOnNotification = patch.peekOnNotification;
    if (typeof patch.idlePill === 'boolean') next.idlePill = patch.idlePill;
    if (typeof patch.weatherCity === 'string' || patch.units) {
      if (typeof patch.weatherCity === 'string') next.weatherCity = patch.weatherCity.trim();
      if (patch.units === 'c' || patch.units === 'f') next.units = patch.units;
      weather.setConfig({ city: next.weatherCity, units: next.units });
    }
    if (typeof patch.launchAtLogin === 'boolean') setAutoStart(patch.launchAtLogin);
    store.set(next);
  });

  ipcMain.on('claude:answer', (_, a) => claude.answer(Number(a.id), a.action, a.text));

  ipcMain.on('bt:refresh', () => bt.refresh());
  ipcMain.on('bt:toggle', (_, a) => bt.toggle(String(a.address), !!a.connect));
  ipcMain.on('bt:add', () => shell.openExternal('ms-settings:bluetooth'));
  ipcMain.on('timer:add', (_, t) => timers.add(t || {}));
  ipcMain.on('timer:remove', (_, id) => timers.remove(Number(id)));
  ipcMain.on('alarm:ack', () => {
    alarmLock = false;
  });

  ipcMain.on('app:quit', () => app.quit());
}

app.whenReady().then(() => {
  const data = app.getPath('userData');
  store = new Store(data);
  clips = new ClipboardWatcher({ dir: path.join(app.getPath('temp'), 'dynamic-island-clips'), max: store.get('maxClips') });
  notifs = new NotificationWatcher({});
  cal = new CalendarWatcher();
  media = new MediaWatcher({ dir: path.join(data, 'media') });
  claude = new ClaudeWatcher();
  timers = new TimerService(store);
  weather = new WeatherWatcher();
  bt = new BluetoothWatcher({ dir: path.join(data, 'bluetooth') });

  if (!store.get('autoStartInit')) {
    setAutoStart(true); // on by default, first launch only; user can turn it off
    store.set({ autoStartInit: true });
  }

  createWindow();
  createTray();
  wireIpc();

  clips.on('change', (v) => send('clips', v));
  notifs.on('change', (v) => send('notifications', v));
  notifs.on('status', (v) => send('notif:status', v));
  cal.on('change', (v) => send('calendar', v));
  media.on('change', (v) => send('media', v));
  weather.on('change', (v) => send('weather', v));
  bt.on('change', (v) => send('bt', v));
  timers.on('change', (v) => send('timers', v));
  timers.on('fire', (t) => {
    alarmLock = true;
    setTimeout(() => (alarmLock = false), 90000);
    send('timer:fire', t);
    setOpen(true);
  });
  claude.on('change', (v) => send('claude', v));
  claude.on('request', (r) => {
    send('claude:request', r);
    if (r.kind === 'permission') setOpen(true); // needs a decision: come out of hiding
  });
  claude.on('request-end', (id) => {
    send('claude:request-end', id);
  });
  notifs.on('new', (fresh) => {
    if (!store.get('peekOnNotification') || open) return;
    setOpen(true);
    send('island:peek', fresh[0]);
    holdUntil = Date.now() + 4500; // the cursor tick closes it afterwards, unless you're hovering
  });

  clips.start();
  notifs.start();
  cal.setUrl(store.get('icsUrl'));
  cal.start();
  media.start();
  claude.start();
  weather.setConfig({ city: store.get('weatherCity'), units: store.get('units') });
  weather.start();
  timers.start();
  bt.start();
  const loop = () => {
    if (quitting) return;
    tick();
    setTimeout(loop, open ? 50 : 90);
  };
  loop();
});

app.on('before-quit', () => {
  quitting = true;
  clearTimeout(closeTimer);
  store?.flush();
  clips?.stop();
  timers?.stop();
  bt?.stop();
  weather?.stop();
  media?.stop();
  claude?.stop();
});
app.on('window-all-closed', (e) => e.preventDefault());
