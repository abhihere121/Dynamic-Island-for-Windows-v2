const { contextBridge, ipcRenderer } = require('electron');

const EVENTS = ['island:open', 'island:pinned', 'island:peek', 'clips', 'notifications', 'calendar', 'media', 'claude', 'claude:request', 'claude:request-end', 'notif:status', 'weather', 'timers', 'timer:fire', 'bt'];
const SEND = [
  'media:control', 'clip:copy', 'clip:remove', 'clip:drag', 'drag:lock', 'edit:lock', 'island:size', 'notes:set',
  'notif:clear', 'notif:dismiss', 'cal:join', 'pin:set', 'settings:set', 'app:quit', 'claude:answer', 'timer:add', 'timer:remove', 'alarm:ack', 'bt:refresh', 'bt:toggle', 'bt:add',
];

contextBridge.exposeInMainWorld('island', {
  getState: () => ipcRenderer.invoke('state:get'),
  on: (channel, cb) => {
    if (EVENTS.includes(channel)) ipcRenderer.on(channel, (_, payload) => cb(payload));
  },
  send: (channel, payload) => {
    if (SEND.includes(channel)) ipcRenderer.send(channel, payload);
  },
});
